﻿using System;
using System.Collections.Generic;

namespace Demo.Service.Models
{
    public partial class Country
    {
        public string CntryCode { get; set; }
        public string CntryName { get; set; }
        public string IsVisaWaiver { get; set; }
    }
}
