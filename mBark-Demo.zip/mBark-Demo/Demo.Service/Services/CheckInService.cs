﻿using Demo.Service.Contracts;
using Demo.Service.Models;
using Demo.Service.Services.Interface;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Demo.Service.Services
{
    public class CheckInService : ICheckInService
    {
        IConfiguration configuration;
        IConfigurationSection applicationSettings;

        public CheckInService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }
        public string CheckIn(CheckInRequest CheckIn)
        {
            string bookingNo = CheckIn.passenger.bookingNo;
            string voyNo = CheckIn.passenger.voyNo;

            var Parent = new Dictionary<string, object>(); //sub dictionary
            var Errors = new List<object>();
            var Warnings = new List<object>();

            using (mBarkDemoAppContext db = new mBarkDemoAppContext())
            {
                try
                {
                    var watch = new Stopwatch();
                    watch.Start();

                    var entity = db.Manifest.Where(e => (e.BookingNo == bookingNo && e.VoyNo == voyNo)).FirstOrDefault();

                    entity.AuthNo = CheckIn.passenger.authNo;
                    entity.Barcode = CheckIn.passenger.barcode;
                    entity.CabinCategory = CheckIn.passenger.cabinCategory;

                    entity.CheckInStatus = CheckIn.passenger.checkInStatus;
                    entity.CheckInWindow = CheckIn.passenger.checkInWindow;
                    entity.ChkInDateTime = CheckIn.passenger.chkInDateTime;

                    entity.DateofBirth = CheckIn.passenger.dateOfBirth;
                    entity.DepartTime = CheckIn.passenger.departTime;
                    entity.DocType = CheckIn.passenger.docType;
                    entity.EmbarkationDate = CheckIn.passenger.embarkationDate;
                    entity.FlagStatus = CheckIn.passenger.flagStatus;
                    entity.Folio = CheckIn.passenger.folio;
                    entity.Gender = CheckIn.passenger.gender;
                    entity.GuestStatus = CheckIn.passenger.guestStatus;
                    entity.IsOlc = CheckIn.passenger.isOLC;
                    entity.Loyalty = CheckIn.passenger.loyalty;
                    entity.MusterStation = CheckIn.passenger.musterStation;

                    entity.RequestedBy = CheckIn.passenger.requestedBy;
                    entity.RequestorName = CheckIn.passenger.requestorName;

                    entity.SailDate = CheckIn.passenger.sailDate;

                    entity.ShipCode = CheckIn.passenger.shipCode;

                    entity.ShipName = CheckIn.passenger.shipName;
                    entity.Title = CheckIn.passenger.title;
                    entity.Zone = CheckIn.passenger.zone;
                    entity.ShipCode = CheckIn.passenger.shipCode;

                    db.SaveChanges();


                    watch.Stop();
                    var duration = (watch.ElapsedMilliseconds).ToString();

                    if (entity.CheckInStatus != null)
                    {
                        Parent.Add("pguestID", CheckIn.passenger.guestId);
                        Parent.Add("pstatus", entity.CheckInStatus);
                        Parent.Add("pmessage", "Guest Document Details Updated");
                        Parent.Add("Errors", Errors.ToList());
                        Parent.Add("Warning", Warnings.ToList());
                        Parent.Add("Success", "True");
                        Parent.Add("message", " ");
                        Parent.Add("timeinmillis", duration);
                        Parent.Add("httpstatusCode", HttpStatusCode.OK);
                    }
                }
                catch (Exception)
                {
                    return ("something went wrong");
                }
            }
            return Parent.ToString();
        }
    }
}
