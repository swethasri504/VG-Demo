﻿using Demo.Service.Contracts;
using Demo.Service.Models;
using Demo.Service.Services.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Demo.Service.Services
{
    public class LoginService : ILoginService
    {      
        IConfiguration configuration;
        IConfigurationSection applicationSettings;

        public LoginService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public string GenerateJSONWebToken(LoginRequest loginrequest)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(configuration["Jwt:Issuer"],
              configuration["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public string AuthenticateUser(LoginRequest loginrequest)
        {
             LoginRequest user = null; 
            
            if (loginrequest.Username == loginrequest.Username)
            {
                user = new LoginRequest { Username = loginrequest.Username, Password = loginrequest.Password };
            }
            return user.ToString();
        
           //return this.Request.CreateResponse(HttpStatusCode.OK, Parent);
            
        }             

    }
}
