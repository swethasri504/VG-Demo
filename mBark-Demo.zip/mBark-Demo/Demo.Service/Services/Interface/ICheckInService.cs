﻿using Demo.Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.Service.Services.Interface
{
   public interface ICheckInService
    {
        string CheckIn(CheckInRequest CheckIn);
    }
}
