﻿using Demo.Service.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.Service.Services.Interface
{
    public interface ILoginService
    {
        string AuthenticateUser(LoginRequest request);
         string GenerateJSONWebToken(LoginRequest request);
        //Task<IEnumerable<LoginService>> ListAsync();
    }
}
