﻿using Demo.Service.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.Service.Services.Interface
{
     public interface IManifestService
    {
        string GetPerson(string shipid, string deviceid, string agentname, string requestid);
    }
}
