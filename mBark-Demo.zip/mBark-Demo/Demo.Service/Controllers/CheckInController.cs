﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Demo.Service.Contracts;
using Demo.Service.Helpers;
using Demo.Service.Models;
using Demo.Service.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace Demo.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CheckInController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private ICheckInService checkInService;

        public CheckInController(IConfiguration config, ICheckInService service)
        {
            this.configuration = config;
            this.checkInService = service;
        }
       
        [HttpPost]
        [Authorize]
        public IActionResult CheckIn([FromBody] CheckInRequest CheckIn)
        {
            var response = this.checkInService.CheckIn(CheckIn);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
