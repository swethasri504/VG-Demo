﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Demo.Service.Contracts;
using Demo.Service.Helpers;
using Demo.Service.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authorization;
using Demo.Service.Services;
using Demo.Service.Services.Interface;

namespace Demo.Service.Controllers
{
    using Contracts;
    using Helpers;
    using System.ComponentModel.DataAnnotations;

    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration configuration;
        public ILoginService loginService;        

        public LoginController(IConfiguration config, ILoginService service)
        {
            configuration = config;
            loginService = service;           
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult AuthLogin([FromBody] LoginRequest loginrequest)
        {
            var username = loginrequest.Username;
            
            var password = loginrequest.Password;
            IActionResult response = Unauthorized();
            var Parent = new Dictionary<string, object>();

            var Errors = new List<object>();
            var Warnings = new List<object>();

            using (mBarkDemoAppContext db = new mBarkDemoAppContext())
            {
                try
                {
                     var entity = db.Userslogin.Where(e => (e.Username == username && e.Password == password)).FirstOrDefault();

                    var user = loginService.AuthenticateUser(loginrequest);

                    if (user != null)
                    {
                        var tokenString = loginService.GenerateJSONWebToken(loginrequest);

                        Parent.Add("access_token", tokenString);
                        Parent.Add("token_type", "bearer");                      
                        Parent.Add("expires_in", TimeSpan.FromDays(1).TotalSeconds);
                        Parent.Add("userName", loginrequest.Username);
                        Parent.Add("roles", loginrequest.Username);
                        Parent.Add("initialPasswordChanged", "true");
                        Parent.Add(".issued", DateTime.Now.ToString("ddd, dd MMM yyy HH:mm:ss 'GMT'"));
                        Parent.Add(".expires", DateTime.Now.AddDays(1).ToString("ddd, dd MMM yyy HH:mm:ss 'GMT'"));
                    }
                    else
                    {
                        Parent.Add("Errors", Errors.ToList());
                        Parent.Add("Warning", Warnings.ToList());
                        Parent.Add("HttpstatusCode", HttpStatusCode.BadRequest);
                    }
                }
                catch (Exception)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "something went wrong");
                }

            }
            return this.Request.CreateResponse(HttpStatusCode.OK, Parent);
        }
    }
}