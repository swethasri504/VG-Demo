﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Demo.Service.Helpers;
using Demo.Service.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Demo.Service.Services.Interface;
using Microsoft.Extensions.Configuration;

namespace Demo.Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ManifestController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IManifestService manifestService;

        public ManifestController(IConfiguration config, IManifestService service)
        {
            this.configuration = config;
            this.manifestService = service;
        }

        [HttpGet]
        [Authorize]
        public IActionResult manifest([FromQuery] string shipid,string deviceid,string agentname,string requestid)
        {           
            var metadatadetails = this.manifestService.GetPerson(shipid, deviceid,  agentname, requestid);
            return this.Request.CreateResponse(HttpStatusCode.OK, metadatadetails);          
        }
    }
}