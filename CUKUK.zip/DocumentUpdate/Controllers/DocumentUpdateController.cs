﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using DocumentUpdate.Models;

namespace DocumentUpdate.Controllers
{
    public class DocumentUpdateController : ApiController
    {
        [HttpPut]
        public HttpResponseMessage UpdateDocument([FromBody] UpdateDocumentRequest bookingRequest)
        {
            //retrieving the bookingno and guestid from db
            
            string bookingno = bookingRequest.booking.bookingno;
            string guestid = bookingRequest.booking.personalinfo.guestid;

            var Parent = new Dictionary<String, object>();
            var booking = new Dictionary<String, object>();
            var checkin = new Dictionary<String, object>();

            using (olcdbEntities2 db = new olcdbEntities2())
            {
                try
                {
                    //Query for Document Updation based on bookingno and guestid
                    var entity = db.bookingdetails.Where(e => (e.bookingno == bookingno && e.guestid == guestid)).FirstOrDefault();

                    if (entity == null)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Bookingdetails with id=" + bookingno + "not found to update");
                    }
                    else
                    {
                        //getting the booking details from db 
                        bookingRequest.booking.voyno = entity.voyno;
                        bookingRequest.booking.bookingno = entity.bookingno;
                        bookingRequest.booking.shipcode = entity.shipcode;
                        bookingRequest.booking.shipname = entity.shipname;
                        bookingRequest.booking.embarkationdate = entity.embarkationdate;
                        bookingRequest.booking.debarkationdate = entity.debarkationdate;

                        //Getting the personalinfo details from dd
                        bookingRequest.booking.personalinfo.seqno = entity.seqno;
                        bookingRequest.booking.personalinfo.guestid = entity.guestid;
                        bookingRequest.booking.personalinfo.folio = entity.folio;
                        bookingRequest.booking.personalinfo.plastname = entity.plastname;
                        bookingRequest.booking.personalinfo.middlename = entity.middlename;
                        bookingRequest.booking.personalinfo.firstname = entity.firstname;
                        bookingRequest.booking.personalinfo.title = entity.title;
                        bookingRequest.booking.personalinfo.gender = entity.gender;
                        bookingRequest.booking.personalinfo.loyalty = entity.loyalty;
                        bookingRequest.booking.personalinfo.isresponsible = entity.isresponsible;
                        bookingRequest.booking.personalinfo.guesttype = entity.guesttype;
                        bookingRequest.booking.personalinfo.barcode = entity.barcode;
                        bookingRequest.booking.personalinfo.cabin = entity.cabin;


                        //updating the document details into the db
                        entity.givenname = bookingRequest.booking.document.givenname;
                        entity.dlastname = bookingRequest.booking.document.dlastname;
                        entity.doctype = bookingRequest.booking.document.doctype;
                        entity.docnumber = bookingRequest.booking.document.docnumber;
                        entity.docissuedate = bookingRequest.booking.document.docissuedate;
                        entity.docexpirydate = bookingRequest.booking.document.docexpirydate;
                        entity.docissuecountry = bookingRequest.booking.document.docissuecountry;
                        entity.dateofbirth = bookingRequest.booking.document.dateofbirth;
                        entity.placeofbirth = bookingRequest.booking.document.placeofbirth;
                        entity.nationality = bookingRequest.booking.document.nationality;
                        entity.countryofbirth = bookingRequest.booking.document.countryofbirth;

                        var watch = new Stopwatch();
                        watch.Start();
                        watch.Stop();
                        var responseTimeForCompleteRequest = watch.ElapsedMilliseconds;

                        if (bookingRequest.booking.document == null)
                        {
                            Parent.Add("status", "N");
                            Parent.Add("message", "Guest Document Details not Updated");
                            Parent.Add("timeinmillis", responseTimeForCompleteRequest);
                            entity.isdocumentinfocomplete = "N";
                        }
                        else
                        {
                            db.SaveChanges();

                            Parent.Add("status", "Y");
                            Parent.Add("message", "Guest Document Details Updated");
                            Parent.Add("timeinmillis", responseTimeForCompleteRequest);
                            entity.isdocumentinfocomplete = "Y";
                        }

                        booking.Add("voyno", bookingRequest.booking.voyno);
                        booking.Add("bookingno", bookingRequest.booking.bookingno);
                        booking.Add("checkinstatus", checkin);

                        checkin.Add("isolc", entity.isolc);
                        checkin.Add("ispaymentcomplete", entity.ispaymentcomplete);
                        checkin.Add("isdocumentinfocomplete", entity.isdocumentinfocomplete);

                        booking.Add("guestid", bookingRequest.booking.personalinfo.guestid);

                        Parent.Add("Booking", booking);

                        return Request.CreateResponse(HttpStatusCode.OK, Parent);
                    }
                }
                catch (Exception ex)
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
                }
            }
        }
    }
}

