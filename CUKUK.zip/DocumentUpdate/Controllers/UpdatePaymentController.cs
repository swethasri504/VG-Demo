﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Remoting.Contexts;
using System.Web.Http;
using System.Web.Http.Description;
using Newtonsoft.Json.Linq;
using System.Web.Http.ModelBinding;
using CUKUK.Models;
using DocumentUpdate;
using System.Web.Http.Cors;

namespace CUKUK.Controllers
{
    
    //[RoutePrefix("api/UpdatePayment")]
    public class UpdatePaymentController : ApiController
    {
        [HttpPut]
        public HttpResponseMessage UpdateCredit([FromBody] Request bookingRequest)
        {
            string bookingno = bookingRequest.booking.bookingno;

            List<Models.Guest> list = bookingRequest.booking.creditcardinfo.guestsmapped;
            var Parent = new Dictionary<String, object>();
            var gbooking = new Dictionary<String, object>();


            gbooking.Add("voyno", bookingRequest.booking.voyno);
            gbooking.Add("bookingno", bookingRequest.booking.bookingno);

            Parent.Add("status", "00");
            Parent.Add("message", "Guest Payment Card Details Updated");
            Parent.Add("timeinmillis", "400");
            var guestid = "";


            var book = new Dictionary<string, object>();
            var guestlist = new Dictionary<string, object>();
            var guests = new List<object>();

            for (int i = 0; i < list.Count; i++)
            {
                var check = new Dictionary<string, object>();
                var checkin = new Dictionary<String, object>();

                //guestidtest = test.personalinfo.guestid;
                guestid = bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.guestid;
                checkin.Add("guestid", guestid);

                check.Add("isolc", "Y");
                check.Add("ispaymentcomplete", "Y");
                check.Add("isdocumentinfocomplete", "Y");

                checkin.Add("checkinstatus", check);
                guests.Add(checkin);

                using (olcdbEntities2 db = new olcdbEntities2())
                {
                    try
                    {
                        var entity = db.bookingdetails.Where(e => (e.bookingno == bookingno && e.guestid == guestid)).FirstOrDefault();

                        if (entity == null)
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Bookingdetails with id=" + bookingno + "not found to update");
                        }

                        else
                        {
                            bookingRequest.booking.voyno = entity.voyno;
                            bookingRequest.booking.bookingno = entity.bookingno;
                            bookingRequest.booking.shipcode = entity.shipcode;
                            bookingRequest.booking.shipname = entity.shipname;
                            bookingRequest.booking.embarkationdate = entity.embarkationdate;
                            bookingRequest.booking.debarkationdate = entity.debarkationdate;

                            entity.registeredcardid = bookingRequest.booking.creditcardinfo.registeredcardid;
                            entity.ccholdername = bookingRequest.booking.creditcardinfo.ccholdername;
                            entity.ccmaskedno = bookingRequest.booking.creditcardinfo.ccmaskedno;
                            entity.ccexpiry = bookingRequest.booking.creditcardinfo.ccexpiry;
                            entity.cctype = bookingRequest.booking.creditcardinfo.cctype;
                            entity.currencycode = bookingRequest.booking.creditcardinfo.currencycode;
                            entity.cctoken = bookingRequest.booking.creditcardinfo.cctoken;
                            entity.iscctokenpresent = bookingRequest.booking.creditcardinfo.iscctokenpresent;

                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.seqno = entity.seqno;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.guestid = entity.guestid;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.folio = entity.folio;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.plastname = entity.plastname;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.middlename = entity.middlename;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.firstname = entity.firstname;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.title = entity.title;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.gender = entity.gender;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.loyalty = entity.loyalty;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.isresponsible = entity.isresponsible;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.guesttype = entity.guesttype;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.barcode = entity.barcode;
                            bookingRequest.booking.creditcardinfo.guestsmapped[i].personalinfo.cabin = entity.cabin;
                            db.SaveChanges();
                        }
                    }

                    catch (Exception ex)
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
                    }
                }
            }
            gbooking.Add("guests", guests);
            Parent.Add("booking", gbooking);

            //string guestid = bookingRequest.booking.creditcardinfo.guestsmapped[0].personalinfo.guestid;

            //Booking booking = new Booking();

            return Request.CreateResponse(HttpStatusCode.OK, Parent);
        }
    }
}

/* public string updatePayment(bookingdetail mode)
 {
     using (olcdbEntities2 db = new olcdbEntities2())
     {
         bookingdetail bd = db.bookingdetails.Where(c => c.bookingno == mode.bookingno).Single<bookingdetail>();
         if (bd == null)
         {
             return ("Bookingdetails with id=" + bd.bookingno.ToString() + "not found to update");
         }
         else
         {

             bd.bookingno = mode.bookingno;
             bd.registeredcardid = mode.registeredcardid;
             bd.ccholdername = mode.ccholdername;
             bd.ccmaskedno = mode.ccmaskedno;
             bd.ccexpiry = mode.ccexpiry;
             bd.cctype = mode.cctype;
             bd.ccexpiry = mode.ccexpiry;
             bd.currencycode = mode.currencycode;
             bd.cctoken = mode.cctoken;
             bd.ccissuedate = mode.ccissuedate;
             bd.iscctokenpresent = mode.iscctokenpresent;

             db.Entry(bd).State = System.Data.Entity.EntityState.Modified;
             db.SaveChanges();
             return "Hey!! Gopal your Data Updated Successfully...";
         }
     }
 }*/
