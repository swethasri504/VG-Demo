using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using Newtonsoft.Json;
using System.Collections;
using CarnivalUK.Models;
using System.Net.Http.Headers;
using DocumentUpdate;
using System.Web.Http.Cors;

namespace CarnivalUK.Controllers
{
    public class CarnivalController : ApiController
    {

        [HttpGet]
        public HttpResponseMessage Get([FromBody] GetRequest bookingRequest)
        {
            var count = 0;
            //
            var bookingdetails = new Dictionary<string, object>(); //parent dictionary
            var booking = new Dictionary<string, object>(); //sub dictionary

            string bookingno = bookingRequest.bookingno;
            

            using (olcdbEntities2 db = new olcdbEntities2())
            {
                var entity = db.bookingdetails.Where(a => a.bookingno == bookingno);
               
              
                var guest = new List<object>(); //list of arry

                    foreach (var result in entity)
                    {

                        var personalinfo = new Dictionary<string, object>(); //sub dictionary
                        var checkinstatus = new Dictionary<string, object>(); //sub dictionary
                        var document = new Dictionary<string, object>(); //sub dictionary
                        var guestlist = new Dictionary<string, object>(); //list of sub dictionary

                        personalinfo.Add("seqno", result.seqno);
                        personalinfo.Add("guestid", result.guestid);
                        personalinfo.Add("folio", result.folio);
                        personalinfo.Add("lastname", result.plastname);
                        personalinfo.Add("middlename", result.middlename);
                        personalinfo.Add("firstname", result.firstname);
                        personalinfo.Add("title", result.title);
                        personalinfo.Add("gender", result.gender);
                        personalinfo.Add("loyalty", result.loyalty);
                        personalinfo.Add("isresponsible", result.isresponsible);
                        personalinfo.Add("guesttype", result.guesttype);
                        personalinfo.Add("barcode", result.barcode);
                        personalinfo.Add("cabin", result.cabin);

                        //checkinstatus
                        checkinstatus.Add("isolc", result.isolc);
                        checkinstatus.Add("ispaymentcomplete", result.ispaymentcomplete);
                        checkinstatus.Add("isdocumentinfocomplete", result.isdocumentinfocomplete);

                        //document
                        document.Add("givenname", result.givenname);
                        document.Add("lastname", result.dlastname);
                        document.Add("doctype", result.doctype);
                        document.Add("docnumber", result.docnumber);
                        document.Add("docissuedate", result.docissuedate);
                        document.Add("docexpirydate", result.docexpirydate);
                        document.Add("docissuecountry", result.docissuedate);
                        document.Add("dateofbirth", result.dateofbirth);
                        document.Add("placeofbirth", result.placeofbirth);
                        document.Add("nationality", result.nationality);

                        //booking 
                        if (count == 0)
                        {
                            booking.Add("voyno", result.voyno);
                            booking.Add("bookingno", result.bookingno);
                            booking.Add("shipcode", result.shipcode);
                            booking.Add("shipname", result.shipname);
                            booking.Add("embarkationdate", result.embarkationdate);
                            booking.Add("debarkationdate", result.debarkationdate);
                            booking.Add("olcenabled", result.olcenabled);
                            booking.Add("message", result.message);
                        }

                        guestlist.Add("checkinstatus", checkinstatus);
                        guestlist.Add("personalinfo", personalinfo);
                        guestlist.Add("document", document);
                        guest.Add(guestlist);

                        count++;
                    }
                
                    booking.Add("guests", guest);
                    //parent Dictionary
                    bookingdetails.Add("booking", booking);
                    //booking = db.bookingdetails.OrderBy(a => a.bookingno).ToList(); 
                    return Request.CreateResponse(HttpStatusCode.OK, bookingdetails);
            }
        }
    }
  
}
