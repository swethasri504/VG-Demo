﻿namespace DocumentUpdate.Controllers
{
    internal class ResponseMessage
    {
    }
}