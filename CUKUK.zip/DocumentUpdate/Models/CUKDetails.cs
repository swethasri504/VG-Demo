﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarnivalUK.Models
{
    public class GetRequest
    {
        [JsonProperty("bookingno")]
        public string bookingno { get; set; }

        [JsonProperty("firstname")]
        public string firstname { get; set; }

        [JsonProperty("lastname")]
        public string lastname { get; set; }

        [JsonProperty("dateofbirth")]
        public string dateofbirth
        {
            get; set;
        }
    }
}


    
        


 
