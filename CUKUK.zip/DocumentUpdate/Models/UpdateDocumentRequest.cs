﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DocumentUpdate.Models
{
    public class UpdateDocumentRequest
    {
        [JsonProperty("booking")]
        public Booking booking { get; set; }
    }
    public class Booking
    {

        [JsonProperty("personalinfo")]
        public Personalinfo personalinfo { get; set; }

        [JsonProperty("Document")]
        public Document document { get; set; }

        [JsonProperty]
        public string voyno { get; set; }
        [JsonProperty]
        public string bookingno { get; set; }
        [JsonProperty]
        public string shipcode { get; set; }
        [JsonProperty]
        public string shipname { get; set; }
        [JsonProperty]
        public string embarkationdate { get; set; }
        [JsonProperty]
        public string debarkationdate { get; set; }
    }

    public class Personalinfo
    {
       
        [JsonProperty]
        public string seqno { get; set; }
        [JsonProperty]
        public string guestid { get; set; }
        [JsonProperty]
        public string folio { get; set; }
        [JsonProperty]
        public string plastname { get; set; }
        [JsonProperty]
        public string middlename { get; set; }
        [JsonProperty]
        public string firstname { get; set; }
        [JsonProperty]
        public string title { get; set; }
        [JsonProperty]
        public string gender { get; set; }
        [JsonProperty]
        public string loyalty { get; set; }
        [JsonProperty]
        public string isresponsible { get; set; }
        [JsonProperty]
        public string guesttype { get; set; }
        [JsonProperty]
        public string barcode { get; set; }
        [JsonProperty]
        public string cabin { get; set; }
        //[JsonProperty]
        //public string musterstation { get; set; }

    }
    public class Document
    {
        [JsonProperty]
        public string givenname { get; set; }
        [JsonProperty]
        public string dlastname { get; set; }
        [JsonProperty]
        public string doctype { get; set; }
        [JsonProperty]
        public string docnumber { get; set; }
        [JsonProperty]
        public string docissuedate { get; set; }
        [JsonProperty]
        public string docexpirydate { get; set; }
        [JsonProperty]
        public string docissuecountry { get; set; }
        [JsonProperty]
        public string dateofbirth { get; set; }
        [JsonProperty]
        public string placeofbirth { get; set; }
        [JsonProperty]
        public string nationality { get; set; }
        [JsonProperty]
        public string countryofbirth { get; set; }
    }
   
}