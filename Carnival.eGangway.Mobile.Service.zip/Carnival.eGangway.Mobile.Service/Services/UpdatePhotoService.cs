﻿using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Instrumentation;
using Carnival.eGangway.Mobile.Service.Interface;
using Carnival.eGangway.Mobile.Service.Repository;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net.Http;

namespace Carnival.eGangway.Mobile.Service
{
    public class UpdatePhotoService : IUpdatePhotoService
	{
		public const string ExternalApi = "UpdatePhoto";
		IConfiguration configuration;
        IConfigurationSection applicationSettings;
        ICacheService cacheService;

        public UpdatePhotoService(IConfiguration configuration, ICacheService cacheService)
		{
			this.configuration = configuration;
            this.cacheService = cacheService;
			this.applicationSettings = configuration.GetSection("ApplicationSettings");
		}
		private UpdatePhotoResponse ProcessRequest(UpdatePhotoRequest PhotoRequest)
		{
			UpdatePhotoResponse PhotoResponse = null;
			var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, ExternalApi);
            var watch = new Stopwatch();

			var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, PhotoRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response?.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            string jsonString = JsonConvert.SerializeObject(PhotoRequest);

            InstrumentationContext.Current.Important("UpdatePhoto.Request", string.Format("UpdatePhoto Request: {0}", jsonString));
           
            InstrmentationLogHelper.LogExternalApiResponse("External.Api.UpdatePhoto", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
			{                
                string externalReponse = string.Format("External.Api.UpdatePhoto StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }			

			if (response != null)
			{
				PhotoResponse = JsonConvert.DeserializeObject<UpdatePhotoResponse>(result);
			}
			return PhotoResponse;
		}
		public UpdatePhotoResponse UpdatePhoto(UpdatePhotoRequest request)
		{
            var hashString = HashGenerator.GenerateKey(JsonConvert.SerializeObject(request));
            var record = cacheService.Get(hashString);
            if (record != null)
            {
                return JsonConvert.DeserializeObject<UpdatePhotoResponse>(record.Response);
            }
            var response = ProcessRequest(request);
            try
            {
                var transactionId = Guid.NewGuid().ToString();
                response.TransactionId = transactionId;
                cacheService.Add(new Record
                {
                    Id = transactionId,
                    MD5 = hashString,
                    StartDate = DateTime.Now,
                    Response = JsonConvert.SerializeObject(response)
                });
            }
            catch (Exception ex)
            {
                InstrumentationContext.Current.Exception(
                "Gangway.Mobile.PhotoService.ProcessRequest", ex, "Error which fetching Photo");
            }
            return response;
		}

        public void UpdatePhotoCache(string transactionId)
        {
            try
            {
                cacheService.Remove(transactionId);
            }
            catch (Exception ex)
            {
                InstrumentationContext.Current.Exception(
                "Gangway.Mobile.PhotoService.ProcessRequest", ex, "Error which clearing update Photo cache");
            }
        }
    }
}
