﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service;
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Carnival.eGangway.Mobile.Service.Instrumentation;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.Http;

    public class ManifestService : IManifestService
    {
        public const string ExternalApiMetadataRoute = "api/manifest?shipid={0}&deviceid={1}";
        IConfiguration configuration;
        IConfigurationSection applicationSettings;       

        public ManifestService(IConfiguration configuration)
        {
            this.configuration = configuration;            
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public ManifestResponse GetResponse(ManifestRequest request)
        {
            return this.ProcessRequest(request);
        }
        public ManifestResponse ProcessRequest(ManifestRequest metadataRequest)
        {
            ManifestResponse manifestResponse = null;
            var baseUri = this.applicationSettings.GetValue<string>("BaseUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = string.Format(ExternalApiMetadataRoute, metadataRequest.ShipId, metadataRequest.DeviceId);
            var watch = new Stopwatch();

            var client = new HttpClient();
            using (var request = new HttpRequestMessage(HttpMethod.Get, Path.Combine(baseUri, requestUri)))
            {
                request.Headers.Add("Authorization", string.Format("bearer {0}", metadataRequest.AccessToken));
                request.Headers.Add("x-deviceid", metadataRequest.DeviceId);

                // Adding latitude auth header
                client.AddLatitudeAuthTokenHeader(latAuthToken);

                watch.Start();
                var response = client.SendAsync(request).GetAwaiter().GetResult();
                watch.Stop();
                var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

                var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

                InstrmentationLogHelper.LogExternalApiResponse("External.Api.Manifest", request.RequestUri.ToString(), request.Method.ToString(), response.StatusCode, result, duration, metadataRequest.DeviceId);

                if (!response.IsSuccessStatusCode)
                {
                    string externalReponse = string.Format("External.Api.Manifest StatusCode {0}, RequestUri {1} {2}", response.StatusCode, request.Method, requestUri);                    
                    throw new InvalidOperationException(externalReponse);
                }
                
                manifestResponse = JsonConvert.DeserializeObject<ManifestResponse>(result);
            }
            return manifestResponse;

        }

        
    }
}
