﻿using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Instrumentation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Repository;

namespace Carnival.eGangway.Mobile.Service
{
    public class MovementService : IMovementService
    {
        public const string ExternalApi = "UpdateMovement";
        IConfiguration configuration;
        IConfigurationSection applicationSettings;
        IDashboardService dashboardService;
        ICacheService cacheService;
        const string VALUES_SEPARATOR = ":";


        public MovementService(IConfiguration configuration, IDashboardService dashboardService, ICacheService cacheService)
        {
            this.configuration = configuration;
            this.dashboardService = dashboardService;
            this.cacheService = cacheService;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        private UpdateMovementResponse ProcessRequest(UpdateMovementRequest updateMovementRequest)
        {
            UpdateMovementResponse movementResponse = null;

            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, ExternalApi);
            var watch = new Stopwatch();

            var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, updateMovementRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response?.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            string jsonString = JsonConvert.SerializeObject(updateMovementRequest);

            InstrumentationContext.Current.Important("MovementService.Request", string.Format("UpdateMovement Request: {0}", jsonString));

            InstrmentationLogHelper.LogExternalApiResponse("External.Api.UpdateMovement", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
            {
                string externalReponse = string.Format("External.Api.UpdateMovement StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }

            if (response != null)
            {
                movementResponse = JsonConvert.DeserializeObject<UpdateMovementResponse>(result);
            }

            return movementResponse;
        }

        public UpdateMovementResponse UpdateMovement(UpdateMovementRequest request)
        {
            this.ValidateRequest(request);
            var hashString = HashGenerator.GenerateKey(JsonConvert.SerializeObject(request));
            var record = cacheService.Get(hashString);
            if (record != null)
            {
                return JsonConvert.DeserializeObject<UpdateMovementResponse>(record.Response);
            }
            var response = ProcessRequest(request);
            try
            {
                var dashboardResponse = this.dashboardService.GetCounts(voyno: new List<string> { request.VoyNo });
                response.Dashboard = dashboardResponse.Dashboard;
                var transactionId = Guid.NewGuid().ToString();
                response.TransactionId = transactionId;
                cacheService.Add(new Record
                {
                    Id = transactionId,
                    MD5 = hashString,
                    StartDate = DateTime.Now,
                    Response = JsonConvert.SerializeObject(response)
                });
            }
            catch (Exception ex)
            {
                InstrumentationContext.Current.Exception(
                "Gangway.Mobile.MovementService.ProcessRequest", ex, "Error which fetching dashboard count");
            }
            return response;
        }

        public void ValidateRequest(UpdateMovementRequest request)
        {
            if (request.SourceApp.Trim().ToUpper() != "GGYMOB")
            {
                Utils.InvalidOperationExceptionResponse("sourceapp");
            }
        }


        public void UpdateCache(string transactionId)
        {
            try
            {
                cacheService.Remove(transactionId);
            }
            catch (Exception ex)
            {
                InstrumentationContext.Current.Exception(
                "Gangway.Mobile.MovementService.ProcessRequest", ex, "Error which clearing update movement cache");
            }
        }
    }
}
