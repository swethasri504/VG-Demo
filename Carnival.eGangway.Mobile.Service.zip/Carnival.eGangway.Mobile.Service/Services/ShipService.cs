﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Microsoft.Extensions.Configuration;
    using Newtonsoft.Json;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net.Http;

    public class ShipService : IShipService
    {
        public const string ExternalApiGetShipsRoute = "getships";
        public const string ExternalApiGetShipByCodeRoute = "GetShipMetadata";

        IConfiguration configuration;
        IConfigurationSection applicationSettings;   

        public ShipService(IConfiguration configuration)
        {
            this.configuration = configuration;            
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public ShipList GetShips()
        {
            ShipList list = null;

            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, ExternalApiGetShipsRoute);
            var watch = new Stopwatch();

            var client = new HttpClient();

            using (var request = new HttpRequestMessage(HttpMethod.Get, requestUri))
            {
                // Adding latitude auth header
                client.AddLatitudeAuthTokenHeader(latAuthToken);

                watch.Start();
                var response = client.SendAsync(request).GetAwaiter().GetResult();
                watch.Stop();
                var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

                var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

                InstrmentationLogHelper.LogExternalApiResponse("External.Api.GetShips", request.RequestUri.ToString(), request.Method.ToString(), response.StatusCode, result, duration, null);

                if (!response.IsSuccessStatusCode)
                {
                    //var error = (JObject)JsonConvert.DeserializeObject(result);
                    //var errorMsg = string.Format("{0}:{1}", error["error"], error["error_description"]);                  
                    string externalReponse = string.Format("External.Api.GetShips StatusCode {0}, RequestUri {1} {2}", response.StatusCode, request.Method, requestUri);
                    throw new InvalidOperationException(externalReponse);                }

               
                list = JsonConvert.DeserializeObject<ShipList>(result);
            }
            return list;
        }

        public ShipMetadata GetShipByCode()
        {
            ShipMetadata ship = null;
            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, string.Format(ExternalApiGetShipByCodeRoute));
            var watch = new Stopwatch();

            var client = new HttpClient();
            

            using (var request = new HttpRequestMessage(HttpMethod.Get, requestUri))
            {
                // Adding latitude auth header
                client.AddLatitudeAuthTokenHeader(latAuthToken);

                watch.Start();
                var response = client.SendAsync(request).GetAwaiter().GetResult();
                watch.Stop();
                var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

                var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

                InstrmentationLogHelper.LogExternalApiResponse("External.Api.GetShipMetadata", request.RequestUri.ToString(), request.Method.ToString(), response.StatusCode, result, duration, null);

                if (!response.IsSuccessStatusCode)
                {
                    string externalReponse = string.Format("External.Api.GetShipMetadata StatusCode {0}, RequestUri {1} {2}", response.StatusCode, request.Method, requestUri);
                    throw new InvalidOperationException(externalReponse);
                }               
                ship = JsonConvert.DeserializeObject<ShipMetadata>(result);
            }

            return ship;
        }
    }
}
