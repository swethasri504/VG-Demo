﻿

namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Carnival.eGangway.Mobile.Service.Repository;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;

    public class CrewLoginService : ICrewLoginService
    {

        IConfiguration configuration;
        IConfigurationSection applicationSettings;
        ILoginCounter loginCounterService;


        public CrewLoginService(IConfiguration configuration, ILoginCounter loginCounter)
        {
            this.configuration = configuration;
            this.loginCounterService = loginCounter;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public CrewLoginResponse GetCrewUser(CrewLoginRequest request)
        {
            var username = request.Data.FirstOrDefault().LoginId;
            var userLoginStat = loginCounterService.Get(username);
            if (userLoginStat == null || userLoginStat.Attempt < 6)
            {
                var response = this.ProcessRequest(request);
                loginCounterService.Remove(username);
                return response;
            }
            throw new InvalidOperationException("The user as been locked, please contact admin");
        }


        public CrewLoginResponse ProcessRequest(CrewLoginRequest loginRequest)
        {
            CrewLoginResponse externalResponse = null;
            var requestUri = this.applicationSettings.GetValue<string>("LatitudeLoginApi");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var watch = new Stopwatch();

            var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, loginRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            InstrmentationLogHelper.LogExternalApiResponse("External.Api.LatitudeLogin", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == HttpStatusCode.BadRequest)
                {
                    loginCounterService.Add(loginRequest.Data.FirstOrDefault().LoginId);
                }
                string externalReponse = string.Format("External.Api.LatitudeLoginApi StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }
            externalResponse = JsonConvert.DeserializeObject<CrewLoginResponse>(result);

            return externalResponse;
        }

        public void ResetPassword(CrewLoginRequest request, string userNameToReset)
        {
            var user = GetCrewUser(request);
            if (user != null)
            {
                loginCounterService.Remove(userNameToReset);
            }
        }
    }
}
