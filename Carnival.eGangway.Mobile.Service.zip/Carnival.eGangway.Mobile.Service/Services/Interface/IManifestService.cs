﻿using Carnival.eGangway.Mobile.Service.Contracts;

namespace Carnival.eGangway.Mobile.Service
{
    public interface IManifestService
    {    
        ManifestResponse GetResponse(ManifestRequest request);
    }
}
