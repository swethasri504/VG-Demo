﻿using Carnival.eGangway.Mobile.Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Interface
{
    public interface IVisitorService
    {
        VisitorResponse Create(VisitorRequest request);
    }
}
