﻿using Carnival.eGangway.Mobile.Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Interface
{
	public interface IUpdatePhotoService
	{
		UpdatePhotoResponse UpdatePhoto(UpdatePhotoRequest request);

        void UpdatePhotoCache(string transactionId);
    }
}
