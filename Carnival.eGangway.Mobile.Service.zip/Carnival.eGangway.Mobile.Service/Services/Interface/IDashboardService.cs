﻿namespace Carnival.eGangway.Mobile.Service
{
    using System.Collections.Generic;
    using Carnival.eGangway.Mobile.Service.Contracts;
    public interface IDashboardService
    {
        DashboardDetails GetCounts(List<string> voyno);   
    }
}
