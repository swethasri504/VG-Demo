﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    public interface IShipService
    {
        ShipList GetShips();
        ShipMetadata GetShipByCode();
    }
}
