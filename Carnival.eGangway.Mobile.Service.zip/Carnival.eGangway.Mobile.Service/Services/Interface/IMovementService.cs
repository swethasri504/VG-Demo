﻿using Carnival.eGangway.Mobile.Service.Contracts;
using System;

namespace Carnival.eGangway.Mobile.Service
{
    public interface IMovementService
    {
        UpdateMovementResponse UpdateMovement(UpdateMovementRequest request);

        void UpdateCache(string transactionId);
    }
}
