﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    public interface IPersonService
    {
        PersonManifest GetPerson(string voyNo);        
    }
}
