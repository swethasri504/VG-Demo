﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Carnival.eGangway.Mobile.Service.Instrumentation;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.Http;

    public class PersonService : IPersonService
    {        
        public const string ExternalApiGetPersonRoute = "GetPerson/{0}";

        IConfiguration configuration;
        IConfigurationSection applicationSettings;      


        public PersonService(IConfiguration configuration)
        {
            this.configuration = configuration;            
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public PersonManifest GetPerson(string voyNo)
        {
            PersonManifest person = null;

            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, string.Format(ExternalApiGetPersonRoute, voyNo));
            var watch = new Stopwatch();


            var client = new HttpClient();

            using (var request = new HttpRequestMessage(HttpMethod.Get, requestUri))
            {
                // Adding latitude auth header
                client.AddLatitudeAuthTokenHeader(latAuthToken);

                watch.Start();
                var response = client.SendAsync(request).GetAwaiter().GetResult();
                watch.Stop();
                var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

                var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

                InstrmentationLogHelper.LogExternalApiResponse("External.Api.GetPerson", request.RequestUri.ToString(), request.Method.ToString(), response.StatusCode, null, duration, null);

                if (!response.IsSuccessStatusCode)
                {                   
                    string externalReponse = string.Format("External.Api.GetPerson StatusCode {0}, RequestUri {1} {2}", response.StatusCode, request.Method.ToString(), requestUri);
                    throw new InvalidOperationException(externalReponse);
                }

                person = JsonConvert.DeserializeObject<PersonManifest>(result);
            }
            return person;
        }        
    }
}
