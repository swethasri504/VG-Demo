﻿using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Instrumentation;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service
{
    public class UpdateEventService : IUpdateEventService
    {
        public const string ExternalApi = "UpdateEvent";
        IConfiguration configuration;
        IConfigurationSection applicationSettings;       

        UpdateEventRequest[] array = new UpdateEventRequest[] { };

        public UpdateEventService(IConfiguration configuration)
        {
            this.configuration = configuration;            
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        private UpdateEventResponse ProcessRequest(UpdateEventRequest updateEventRequest)
        {
            UpdateEventResponse eventResponse = null;
            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, ExternalApi);
            var watch = new Stopwatch();

            var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, updateEventRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response?.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            string jsonString = JsonConvert.SerializeObject(updateEventRequest);

            InstrumentationContext.Current.Important("UpdateEvent.Request", string.Format("UpdateEvent Request: {0}", jsonString));
            
            InstrmentationLogHelper.LogExternalApiResponse("External.Api.UpdateEvent", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
            {             
                string externalReponse = string.Format("External.Api.UpdateEvent StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }

            if (response != null)
            {
                eventResponse = JsonConvert.DeserializeObject<UpdateEventResponse>(result);
            }

            if (string.IsNullOrEmpty(eventResponse.Status) || eventResponse.Status.ToUpper() == "N")
            {
                eventResponse.Status = "N";
                eventResponse.Message = string.Format("Update event fail for eventId: {0}", updateEventRequest.EventId);
                eventResponse.TimeInMillis = eventResponse.TimeInMillis;
                eventResponse.ResponseCode = eventResponse.ResponseCode;
                eventResponse.EventDetails = array.ToList();
                eventResponse.UpdateMovement = null;
            }

            return eventResponse;
        }
        
        public UpdateEventResponse UpdateEvent(UpdateEventRequest request)
        {
            this.ValidateRequest(request);
            return ProcessRequest(request);
        }

        public void ValidateRequest(UpdateEventRequest request)
        {
            if (request.EventType.Trim().ToUpper() == "ALERT")
            {
                if (string.IsNullOrEmpty(request.OverriddenBy))
                    Utils.InvalidOperationExceptionResponse("overriddenBy");
                if (string.IsNullOrEmpty(request.OverriddenDatetime))
                    Utils.InvalidOperationExceptionResponse("overriddenDatetime");
                if (!string.IsNullOrEmpty(request.AcknowledgedBy))
                    Utils.InvalidOperationExceptionResponse("acknowledgedBy");
                if (!string.IsNullOrEmpty(request.AcknowledgedDatetime))
                    Utils.InvalidOperationExceptionResponse("acknowledgedDatetime");
            }

            if (request.EventType.Trim().ToUpper() == "MESSAGE")
            {
                if (!string.IsNullOrEmpty(request.OverriddenBy))
                    Utils.InvalidOperationExceptionResponse("overriddenBy");
                if (!string.IsNullOrEmpty(request.OverriddenDatetime))
                    Utils.InvalidOperationExceptionResponse("overriddenDatetime");
                if (string.IsNullOrEmpty(request.AcknowledgedBy))
                    Utils.InvalidOperationExceptionResponse("acknowledgedBy");
                if (string.IsNullOrEmpty(request.AcknowledgedDatetime))
                    Utils.InvalidOperationExceptionResponse("acknowledgedDatetime");
            }
        }
    }
}
