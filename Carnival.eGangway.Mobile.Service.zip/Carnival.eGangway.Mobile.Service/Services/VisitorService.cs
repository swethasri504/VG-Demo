﻿using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service
{
    public class VisitorService : IVisitorService
    {
        public const string ExternalApi = "AddVisitor";
        IConfiguration configuration;
        IConfigurationSection applicationSettings;

        public VisitorService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        private VisitorResponse ProcessRequest(VisitorRequest VisitorRequest)
        {
            VisitorResponse visitorResponse = null;
            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, ExternalApi);
            var watch = new Stopwatch();

            var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, VisitorRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response?.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            InstrmentationLogHelper.LogExternalApiResponse("External.Api.AddVisitor", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
            {
                string externalReponse = string.Format("External.Api.AddVisitor StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }

            if (response != null)
            {
                visitorResponse = JsonConvert.DeserializeObject<VisitorResponse>(result);
            }
            return visitorResponse;
        }

        public VisitorResponse Create(VisitorRequest request)
        {
            return ProcessRequest(request);
        }
    }
}
