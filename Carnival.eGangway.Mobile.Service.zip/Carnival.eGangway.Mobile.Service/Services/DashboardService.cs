﻿namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;

    public class DashboardService : IDashboardService
    {        
        public const string ExternalApiGetCountsRoute = "GetCounts/{0}";

        IConfiguration configuration;
        IConfigurationSection applicationSettings;       

        public DashboardService(IConfiguration configuration)
        {
            this.configuration = configuration;           
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        private void GetCount(string vogno, List<Dashboard> dashboardList)
        {
            Dashboard dashboard = null;
            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, string.Format(ExternalApiGetCountsRoute, vogno));
            var watch = new Stopwatch();

            var client = new HttpClient();

            using (var request = new HttpRequestMessage(HttpMethod.Get, requestUri))
            {
                // Adding latitude auth header
                client.AddLatitudeAuthTokenHeader(latAuthToken);

                watch.Start();
                var response = client.SendAsync(request).GetAwaiter().GetResult();
                watch.Stop();
                var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

                var result = response.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

                InstrmentationLogHelper.LogExternalApiResponse("External.Api.GetCounts", request.RequestUri.ToString(), request.Method.ToString(), response.StatusCode, result, duration, null);

                if (!response.IsSuccessStatusCode)
                {                    
                    string externalReponse = string.Format("External.Api.GetCounts StatusCode {0}, RequestUri {1} {2}", response.StatusCode, request.Method, requestUri);
                    throw new InvalidOperationException(externalReponse);
                }
                
                if (response != null)
                {
                    dashboard = JsonConvert.DeserializeObject<Dashboard>(result);
                }
            }
           dashboard.VogNo = vogno;
           dashboardList.Add(dashboard);
        }

        private void GetCountsAsync(List<string> voyno,List<Dashboard> dashboardList)
        {
            foreach (var item in voyno)
            {
                GetCount(item, dashboardList);
            }
        }
        public DashboardDetails GetCounts(List<string> voyno)
        {
            var dashboardList =  new List<Dashboard>();
            GetCountsAsync(voyno,dashboardList);

            var first = dashboardList.FirstOrDefault();

            if (dashboardList.Count>0){
                
                var total = new Dashboard
                {
                    VogNo = "All Voyages",
                    Message = first.Message,
                    ResponseCode = first.ResponseCode,
                    Status = first.Status,
                    TimeInMillis = first.TimeInMillis,
                    VisitorCounts = new VisitorCounts
                    {
                        MBarkProcessed = dashboardList.Sum(x => x.VisitorCounts.MBarkProcessed),
                        ExpectedToday = dashboardList.Sum(x => x.VisitorCounts.ExpectedToday),
                        Off = dashboardList.Sum(x => x.VisitorCounts.Off),
                        On = dashboardList.Sum(x => x.VisitorCounts.On),
                    },
                    AlertCounts = new AlertCounts
                    {
                        AlertsCreatedToday = dashboardList.Sum(x => x.AlertCounts.AlertsCreatedToday),
                        ActiveAlerts = dashboardList.Sum(x => x.AlertCounts.ActiveAlerts)
                    },
                    CrewCounts = new CrewCounts
                    {
                        Total = dashboardList.Sum(x => x.CrewCounts.Total),
                        ExpectedToday = dashboardList.Sum(x => x.CrewCounts.ExpectedToday),
                        LeavingToday = dashboardList.Sum(x => x.CrewCounts.LeavingToday),
                        Off = dashboardList.Sum(x => x.CrewCounts.Off),
                        On = dashboardList.Sum(x => x.CrewCounts.On),
                        SignedOn = dashboardList.Sum(x => x.CrewCounts.SignedOn)
                    },
                    GuestCounts = new GuestCounts
                    {
                        Total = dashboardList.Sum(x => x.GuestCounts.Total),
                        ExpectedToday = dashboardList.Sum(x => x.GuestCounts.ExpectedToday),
                        CheckedIn = dashboardList.Sum(x => x.GuestCounts.CheckedIn),
                        Off = dashboardList.Sum(x => x.GuestCounts.Off),
                        On = dashboardList.Sum(x => x.GuestCounts.On),
                        NotCheckedIn = dashboardList.Sum(x => x.GuestCounts.NotCheckedIn)
                    },
                    MessageCounts = new MessageCounts
                    {
                        ActiveMessages = dashboardList.Sum(x => x.MessageCounts.ActiveMessages),
                        MessagesCreatedToday = dashboardList.Sum(x => x.MessageCounts.MessagesCreatedToday),
                    }
                };
                dashboardList.Add(total);
            }
            return new DashboardDetails { Dashboard=dashboardList,
                Message = first.Message,
                ResponseCode = first.ResponseCode,
                Status = first.Status,
                TimeInMillis = first.TimeInMillis
            };
        }
    }
}
