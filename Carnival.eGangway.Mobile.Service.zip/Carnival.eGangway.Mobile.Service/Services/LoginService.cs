﻿

namespace Carnival.eGangway.Mobile.Service
{
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Carnival.eGangway.Mobile.Service.Instrumentation;
    using Carnival.eGangway.Mobile.Service.Repository;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Net;
    using System.Net.Http;

    public class LoginService : ILoginService
    {      
        public const string LoginRoute = "Login";
        public const string AdminRole = "admin";
        IConfiguration configuration;
        IConfigurationSection applicationSettings;       
        ILoginCounter loginCounterService;


        public LoginService(IConfiguration configuration, ILoginCounter loginCounter)
        {
            this.configuration = configuration;            
            this.loginCounterService=loginCounter;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public LoginResponse GetUser(LoginRequest request)
        {
            var userLoginStat = loginCounterService.Get(request.AgentId);
            if (userLoginStat ==null || userLoginStat.Attempt<6){
                    var response =  this.ProcessRequest(request);
                    loginCounterService.Remove(request.AgentId);
                    return response;
            }
            throw new InvalidOperationException("The user as been locked, please contanct admin");
        }

        public LoginResponse GetAdminUser(LoginRequest request)
        {
            var result = this.ProcessRequest(request);
            if (result.Role.ToLower().Trim() != AdminRole.ToLower())
            {
                throw new InvalidOperationException("The user is not an admin.");
            }
            return result;
        }

        public LoginResponse ProcessRequest(LoginRequest loginRequest)
        {            
            LoginResponse loginResponse = null;
            var baseUri = this.applicationSettings.GetValue<string>("MobileServiceUri");
            var latAuthToken = this.applicationSettings.GetValue<string>("LatitudeAuthToken");
            var requestUri = Path.Combine(baseUri, LoginRoute);
            var watch = new Stopwatch();

            var client = new HttpClient();

            // Adding latitude auth header
            client.AddLatitudeAuthTokenHeader(latAuthToken);

            watch.Start();
            var response = client.PostAsJsonAsync(requestUri, loginRequest).GetAwaiter().GetResult();
            watch.Stop();
            var duration = (watch.ElapsedMilliseconds).ToString(CultureInfo.InvariantCulture);

            var result = response?.Content != null ? response.Content.ReadAsStringAsync().GetAwaiter().GetResult() : null;

            string jsonString = JsonConvert.SerializeObject(loginRequest);

            InstrumentationContext.Current.Important("Login.Request", string.Format("Login Request: {0}", jsonString));

            InstrmentationLogHelper.LogExternalApiResponse("External.Api.Login", requestUri, "POST", response.StatusCode, result, duration, null);

            if (!response.IsSuccessStatusCode)
            {               
                string externalReponse = string.Format("External.Api.Login StatusCode {0}, RequestUri {1} {2}", response.StatusCode, "POST", requestUri);
                throw new InvalidOperationException(externalReponse);
            }

            if (response != null)
            {
                loginResponse = JsonConvert.DeserializeObject<LoginResponse>(result);
            }

            return loginResponse;
        }      

        public void ResetPassword(LoginRequest request,string userNameToReset)
        {
            var user = GetAdminUser(request);
            if (user !=null){
                
                loginCounterService.Remove(userNameToReset);
            }
        }
    }
}
