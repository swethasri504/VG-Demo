﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public partial class UpdateEventRequest
    {
        [JsonProperty("eventId")]
        public string EventId { get; set; }

        [JsonProperty("eventType")]
        public string EventType { get; set; }

        [JsonProperty("overriddenBy")]
        public string OverriddenBy { get; set; }

        [JsonProperty("overriddenDatetime")]
        public string OverriddenDatetime { get; set; }

        [JsonProperty("acknowledgedBy")]
        public string AcknowledgedBy { get; set; }

        [JsonProperty("acknowledgedDatetime")]
        public string AcknowledgedDatetime { get; set; }

        [JsonProperty("locationName")]
        public string LocationName { get; set; }

        [JsonProperty("voyNo")]
        public string VoyNo { get; set; }

        [JsonProperty("personId")]
        public string PersonId { get; set; }

        [JsonProperty("personType")]
        public string PersonType { get; set; }

        [JsonProperty("agentId")]
        public string AgentId { get; set; }

        [JsonProperty("deviceId")]
        public string DeviceId { get; set; }

        [JsonProperty("locationCode")]
        public string LocationCode { get; set; }

        [JsonProperty("utcDateTime")]
        public string UtcDateTime { get; set; }
    } 
}
