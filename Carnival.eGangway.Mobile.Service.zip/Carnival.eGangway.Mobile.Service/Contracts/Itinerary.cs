﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class Itinerary
    {
        [JsonProperty("itineraryCode")]
        public string ItineraryCode { get; set; }

        [JsonProperty("itineraryDesc")]
        public string ItineraryDesc { get; set; }

        [JsonProperty("duration")]        
        public long Duration { get; set; }

        [JsonProperty("itineraryDetailsList")]
        public List<ItineraryDetailsList> ItineraryDetailsList { get; set; }
    }
}
