﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{   
    using Newtonsoft.Json;

    public partial class Dashboard
    {

        [JsonProperty("vogNo")]
        public string VogNo {get;set;}
        
        [JsonProperty("guestCounts")]
        public GuestCounts GuestCounts { get; set; }

        [JsonProperty("crewCounts")]
        public CrewCounts CrewCounts { get; set; }

        [JsonProperty("visitorCounts")]
        public VisitorCounts VisitorCounts { get; set; }

        [JsonProperty("alertCounts")]
        public AlertCounts AlertCounts { get; set; }

        [JsonProperty("messageCounts")]
        public MessageCounts MessageCounts { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }

        [JsonProperty("responseCode")]
        
        public long ResponseCode { get; set; }
    }

    public partial class AlertCounts
    {
        [JsonProperty("activeAlerts")]
        
        public long ActiveAlerts { get; set; }

        [JsonProperty("alertsCreatedToday")]
        
        public long AlertsCreatedToday { get; set; }
    }

    public partial class CrewCounts
    {
        [JsonProperty("on")]
        
        public long On { get; set; }

        [JsonProperty("off")]
        
        public long Off { get; set; }

        [JsonProperty("signedOn")]
        
        public long SignedOn { get; set; }

        [JsonProperty("leavingToday")]
        
        public long LeavingToday { get; set; }

        [JsonProperty("total")]        
        public long Total { get; set; }

        [JsonProperty("expectedToday")]
        public long ExpectedToday { get; set; }
    }

    public partial class GuestCounts
    {
        [JsonProperty("on")]        
        public long On { get; set; }

        [JsonProperty("off")]        
        public long Off { get; set; }

        [JsonProperty("checkedIn")]        
        public long CheckedIn { get; set; }

        [JsonProperty("notCheckedIn")]        
        public long NotCheckedIn { get; set; }

        [JsonProperty("total")]        
        public long Total { get; set; }

        [JsonProperty("expectedToday")]        
        public long ExpectedToday { get; set; }
    }

    public partial class MessageCounts
    {
        [JsonProperty("activeMessages")]        
        public long ActiveMessages { get; set; }

        [JsonProperty("messagesCreatedToday")]        
        public long MessagesCreatedToday { get; set; }
    }

    public partial class VisitorCounts
    {
        [JsonProperty("on")]
        
        public long On { get; set; }

        [JsonProperty("off")]        
        public long Off { get; set; }

        [JsonProperty("expectedToday")]        
        public long ExpectedToday { get; set; }

        [JsonProperty("mBarkProcessed")]        
        public long MBarkProcessed { get; set; }
    }
}
