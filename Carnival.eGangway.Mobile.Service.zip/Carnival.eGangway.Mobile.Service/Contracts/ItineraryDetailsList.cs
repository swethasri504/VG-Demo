﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    public partial class ItineraryDetailsList
    {
        [JsonProperty("date")]
        public string Date { get; set; }

        [JsonProperty("day")]
        public string Day { get; set; }

        [JsonProperty("port")]
        public string Port { get; set; }

        [JsonProperty("arriveTime")]
        public string ArriveTime { get; set; }

        [JsonProperty("departTime")]        
        public long DepartTime { get; set; }
    }
}
