﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    using System.Collections.Generic;
    public class ShipMetadata
    {
        [JsonProperty("timezone")]
        public string Timezone { get; set; }

        [JsonProperty("daylightSavingTime")]
        public string DaylightSavingTime { get; set; }

        [JsonProperty("voyageList")]
        public List<VoyageList> VoyageList { get; set; }

        [JsonProperty("gangwayLocations")]
        public List<GangwayLocation> GangwayLocations { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }

        [JsonProperty("responseCode")]        
        public long ResponseCode { get; set; }
    }
}
