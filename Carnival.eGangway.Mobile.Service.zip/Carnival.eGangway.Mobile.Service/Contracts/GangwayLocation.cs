﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class GangwayLocation
    {
        [JsonProperty("gangway_location_code")]        
        public long GangwayLocationCode { get; set; }

        [JsonProperty("gangway_location")]
        public string GangwayLocationGangwayLocation { get; set; }

        [JsonProperty("shipClass")]
        public string ShipClass { get; set; }

        [JsonProperty("alias")]
        public string Alias { get; set; }
    }
}
