﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class UpdateMovementResponse
    {
        [JsonProperty("voyNo")]
        public string voyNo { get; set; }

        [JsonProperty("personType")]
        public string PersonType { get; set; }

        [JsonProperty("personId")]
        public string PersonId { get; set; }

        [JsonProperty("shipName")]
        public string ShipName { get; set; }

        [JsonProperty("port")]
        public string Port { get; set; }

        [JsonProperty("movementStatusCode")]
        public string MovementStatusCode { get; set; }

        [JsonProperty("cbp")]
        public string Cbp { get; set; }

        [JsonProperty("movementActivity")]
        public List<MovementActivity> MovementActivity { get; set; }

        [JsonProperty("dashboardCount")]
        public List<Dashboard> Dashboard { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }

        [JsonProperty("responseCode")]
        public string ResponseCode { get; set; }

        [JsonProperty("transactionId")]
        public string TransactionId {get;set;}

    }
    public partial class MovementActivity
    {
        [JsonProperty("movementStatus")]
        public string MovementStatus { get; set; }

        [JsonProperty("dateTime")]
        public string DateTime { get; set; }

        [JsonProperty("locationCode")]
        public string LocationCode { get; set; }
    }
}
