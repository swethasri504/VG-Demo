﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class VisitorRequest
    {
        [JsonProperty("visitor")]
        public Visitor Visitor { get; set; }

    }
}
