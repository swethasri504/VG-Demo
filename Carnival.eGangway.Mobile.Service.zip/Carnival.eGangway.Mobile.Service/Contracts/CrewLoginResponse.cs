﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public partial class CrewLoginResponse
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("data")]
        public List<CrewLoginResponseData> Data { get; set; }

        [JsonProperty("commondata")]
        public List<CommonData> Commondata { get; set; }
    }

    public partial class CommonData
    {
        [JsonProperty("amountFormatMask")]
        public string AmountFormatMask { get; set; }

        [JsonProperty("minAdultAge")]
        public string MinAdultAge { get; set; }

        [JsonProperty("timeout")]
        public string Timeout { get; set; }

        [JsonProperty("timeoutAlert")]
        public string TimeoutAlert { get; set; }
    }

    public partial class CrewLoginResponseData
    {
        [JsonProperty("loginId")]
        public string LoginId { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("position")]
        public string Position { get; set; }

        [JsonProperty("dob")]
        public string Dob { get; set; }

        [JsonProperty("crewPicture")]
        public string CrewPicture { get; set; }

        [JsonProperty("defaultPosition")]
        public string DefaultPosition { get; set; }
    }
}
