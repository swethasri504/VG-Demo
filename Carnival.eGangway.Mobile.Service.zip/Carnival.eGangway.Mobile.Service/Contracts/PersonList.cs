﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    public class PersonList
    {
        [JsonProperty("personType")]
        public string PersonType { get; set; }

        [JsonProperty("personId")]
        public string PersonId { get; set; }

        [JsonProperty("personImage")]
        public string PersonImage { get; set; }

        [JsonProperty("nationality")]
        public string Nationality { get; set; }

        [JsonProperty("docNo")]        
        public string DocNo { get; set; }

        [JsonProperty("docType")]
        public string DocType { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("age")]        
        public string Age { get; set; }

        [JsonProperty("dateOfBirth")]
        public string DateOfBirth { get; set; }

        [JsonProperty("salutation")]
        public string Salutation { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("barcodeBP")]
        public string BarcodeBp { get; set; }

        [JsonProperty("barcodeSS")]
        public string BarcodeSs { get; set; }

        [JsonProperty("onboardStatus")]
        public string OnboardStatus { get; set; }

        [JsonProperty("stateroom")]
        
        public string Stateroom { get; set; }

        [JsonProperty("stateroomOccupancy")]
        
        public string StateroomOccupancy { get; set; }

        [JsonProperty("bookingNo")]
        public string BookingNo { get; set; }

        [JsonProperty("loyalty")]
        public string Loyalty { get; set; }

        [JsonProperty("embarkDate")]
        public string EmbarkDate { get; set; }

        [JsonProperty("debarkDate")]
        public string DebarkDate { get; set; }

        [JsonProperty("fasterToFun")]
        public string FasterToFun { get; set; }

        [JsonProperty("isBackToBack")]
        public string IsBackToBack { get; set; }

        [JsonProperty("travelWithNo")]
        public string TravelWithNo { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("position")]
        public string Position { get; set; }

        [JsonProperty("empNo")]
        public string EmpNo { get; set; }

        [JsonProperty("cabinOccupancy")]
        public string CabinOccupancy { get; set; }

        [JsonProperty("signOnDate")]
        public string SignOnDate { get; set; }

        [JsonProperty("scheduledOffDate")]
        public string ScheduledOffDate { get; set; }

        [JsonProperty("visitorType")]
        public string VisitorType { get; set; }

        [JsonProperty("visitPurpose")]
        public string VisitPurpose { get; set; }

        [JsonProperty("startDateTime")]
        public string StartDateTime { get; set; }

        [JsonProperty("endDateTime")]
        public string EndDateTime { get; set; }

        [JsonProperty("visitorCardNo")]
        public string VisitorCardNo { get; set; }

        [JsonProperty("company")]
        public string Company { get; set; }

        [JsonProperty("departmentPOC")]
        public string DepartmentPoc { get; set; }

        [JsonProperty("contactNo")]
        public string ContactNo { get; set; }

        [JsonProperty("validForShip")]
        public string ValidForShip { get; set; }

        [JsonProperty("checkInStatus")]
        public string CheckInStatus { get; set; }

        [JsonProperty("voyNo")]
        public string VoyNo { get; set; }
    }
}
