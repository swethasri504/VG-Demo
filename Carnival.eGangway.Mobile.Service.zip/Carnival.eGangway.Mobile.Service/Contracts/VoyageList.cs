﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class VoyageList
    {
        [JsonProperty("voyNo")]
        public string VoyNo { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("itinerary")]
        public Itinerary Itinerary { get; set; }
    }
}
