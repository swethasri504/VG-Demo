﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    using System.Collections.Generic;

    public partial class UpdateEventResponse
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }

        [JsonProperty("responseCode")]
        public string ResponseCode { get; set; }

        [JsonProperty("eventDetails")]
        public List<UpdateEventRequest> EventDetails { get; set; }

        [JsonProperty("updateMovement")]
        public UpdateMovementRequest UpdateMovement { get; set; }
    } 
}
