﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public class UpdateMovementRequest
    {
        [JsonProperty("voyNo")]
        public string VoyNo { get; set; }

        [JsonProperty("personType")]
        public string PersonType { get; set; }

        [JsonProperty("personId")]
        public string PersonId { get; set; }

        [JsonProperty("onboardStatus")]
        public string OnboardStatus { get; set; }

        [JsonProperty("agentId")]
        public string AgentId { get; set; }

        [JsonProperty("utcDatetime")]
        public string UtcDatetime { get; set; }

        [JsonProperty("deviceId")]
        public string DeviceId { get; set; }

        [JsonProperty("locationCode")]
        public string LocationCode { get; set; }

        [JsonProperty("processType")]
        public string ProcessType { get; set; }

        [JsonProperty("sourceapp")]
        public string SourceApp { get; set; }

        [JsonProperty("personImage")]
        public string PersonImage { get; set; }

        [JsonProperty("pictureType")]
        public string PictureType { get; set; }

        [JsonProperty("photoDate")]
        public string PhotoDate { get; set; }

        [JsonProperty("direction")]
        public string Direction { get; set; }
    }
}
