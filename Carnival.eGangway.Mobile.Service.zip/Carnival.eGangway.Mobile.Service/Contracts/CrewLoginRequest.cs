﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public partial class CrewLoginRequest
    {
        [JsonProperty("data")]
        public List<CrewLoginRequestData> Data { get; set; }

        public CrewLoginRequest()
        {
            this.Data = new List<CrewLoginRequestData>();
        }
    }

    public partial class CrewLoginRequestData
    {
        [JsonProperty("loginId")]
        public string LoginId { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }
    }
}
