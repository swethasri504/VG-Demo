﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public partial class Visitor
    {
        [JsonProperty("visitorImg")]
        public string VisitorImg { get; set; }

        [JsonProperty("citizenship")]
        public string Citizenship { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("comments")]
        public string Comments { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("company")]
        public string Company { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("departmentPOC")]
        public string DepartmentPOC { get; set; }

        [JsonProperty("dob")]
        public string Dob { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("idNumber")]
        public string IdNumber { get; set; }

        [JsonProperty("idType")]
        public string IdType { get; set; }

        [JsonProperty("contactNumber")]
        public string ContactNumber { get; set; }

        [JsonProperty("visitForPurpose")]
        public string VisitForPurpose { get; set; }

        [JsonProperty("empNo")]
        public string EmpNo { get; set; }

        [JsonProperty("visitorType")]
        public string VisitorType { get; set; }

        [JsonProperty("voyNo")]
        public string VoyNo { get; set; }

        [JsonProperty("requestedBy")]
        public string RequestedBy { get; set; }
    }
}
