﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public class ManifestResponse
    {
        public List<Manifest> Manifest { get; set; }

        public List<object> Errors { get; set; }

        public List<object> Warnings { get; set; }

        public bool Success { get; set; }

        public string Message { get; set; }

        public long TimeInMillis { get; set; }

        public long HttpStatusCode { get; set; }
    }
}
