﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public enum Is { N, Y };
}
