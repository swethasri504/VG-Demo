namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.Net;

    public class BaseResponse
    {
        [JsonProperty("errors")]
        public List<string> Errors { get; set; }
        [JsonProperty("warnings")]
        public List<string> Warnings { get; set; }
        [JsonProperty("success")]
        public bool Success { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }
        [JsonProperty("httpStatusCode")]
        public HttpStatusCode HttpStatusCode { get; set; }

        public BaseResponse()
        {
            this.Errors = new List<string>();
            this.Warnings = new List<string>();
            this.HttpStatusCode = HttpStatusCode.OK;
        }
    }
}
