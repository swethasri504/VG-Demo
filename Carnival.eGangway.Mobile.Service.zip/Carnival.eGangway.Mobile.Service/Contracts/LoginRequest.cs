﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using Newtonsoft.Json;
    using System.ComponentModel.DataAnnotations;
    public class LoginRequest
    {      
        [Required]
        [JsonProperty("password")]
        public string Password { get; set; }

        [Required]
        [JsonProperty("agentId")]
        public string AgentId { get; set; }

        [Required]
        [JsonProperty("deviceId")]
        public string DeviceId { get; set; }

        [Required]
        [JsonProperty("locationCode")]
        public string LocationCode { get; set; }

        [Required]
        [JsonProperty("utcDatetime")]
        public string UtcDatetime { get; set; }

    }
}
