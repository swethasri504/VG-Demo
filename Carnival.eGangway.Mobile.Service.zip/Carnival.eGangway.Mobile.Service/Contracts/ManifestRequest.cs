﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public class ManifestRequest
    {
        public string ShipId { get; set; }

        public string DeviceId { get; set; }

        public string AccessToken { get; set; }
    }
}
