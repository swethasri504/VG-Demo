﻿namespace Carnival.eGangway.Mobile.Service.Contracts
{
    using System;
    using System.Collections.Generic;

    using System.Globalization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    public partial class PersonManifest
    {
        [JsonProperty("personList")]
        public List<PersonList> PersonList { get; set; }

        [JsonProperty("personEventList")]
        public List<PersonEventList> PersonEventList { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("timeInMillis")]
        public long TimeInMillis { get; set; }

        [JsonProperty("responseCode")]        
        public long ResponseCode { get; set; }
    }
}
