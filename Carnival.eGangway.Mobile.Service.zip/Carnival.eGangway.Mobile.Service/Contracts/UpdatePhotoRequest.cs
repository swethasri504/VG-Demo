﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
	public partial class UpdatePhotoRequest
	{
		[JsonProperty("voyNo")]
		public string VoyNo { get; set; }

		[JsonProperty("personId")]
		public string PersonId { get; set; }

		[JsonProperty("personType")]
		public string PersonType { get; set; }

		[JsonProperty("personImage")]
		public string PersonImage { get; set; }

		[JsonProperty("agentId")]
		public string AgentId { get; set; }

		[JsonProperty("deviceId")]
		public string DeviceId { get; set; }

		[JsonProperty("locationCode")]
		public string LocationCode { get; set; }

		[JsonProperty("utcDatetime")]
		public string UtcDatetime { get; set; }		

	}
}
