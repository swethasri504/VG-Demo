﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Contracts
{
    public class PersonEventList
    {
        [JsonProperty("personType")]
        public string PersonType { get; set; }

        [JsonProperty("personId")]
        public string PersonId { get; set; }

        [JsonProperty("eventId")]        
        public string EventId { get; set; }

        [JsonProperty("eventType")]
        public string EventType { get; set; }

        [JsonProperty("location")]
        public string Location { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("createdDatetime")]
        public string CreatedDatetime { get; set; }

        [JsonProperty("canOverride")]
        public string CanOverride { get; set; }

        [JsonProperty("overriddenBy")]
        public string OverriddenBy { get; set; }

        [JsonProperty("overriddenDatetime")]
        public string OverriddenDatetime { get; set; }

        [JsonProperty("alertType")]
        public string AlertType { get; set; }

        [JsonProperty("acknowledgedBy")]
        public string AcknowledgedBy { get; set; }

        [JsonProperty("acknowledgedDatetime")]
        public string AcknowledgedDatetime { get; set; }
    }
}
