﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    /// <summary>
    /// Instrumenation level.
    /// </summary>
    public enum InstrumentationLevel
    {
        Verbose = 0,
        
        Debug = 1,
       
        Information = 2,
      
        Warning = 3,
      
        Error = 4,
     
        Fatal = 5,
       
        Exception = 6,        
      
        Important = 7,

        ApiSuccess = 8,

        ApiFailure = 9

    }
}
