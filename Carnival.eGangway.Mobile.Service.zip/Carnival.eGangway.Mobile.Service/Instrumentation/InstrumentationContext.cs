﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    using Microsoft.Extensions.Logging;
    using System;

    public class InstrumentationContext : MarshalByRefObject
    {
        
        internal const string InstrumentationLoggingContextKey = "InstrumentationLoggingContextKey";

        private static InstrumentationContext emptyContext = new InstrumentationContext(null, null, null, null, Guid.Empty);

        public InstrumentationContext()
            : this(string.Empty, string.Empty, string.Empty, string.Empty)
        {
        }
        
        public InstrumentationContext(string sessionId, string transactionId, string association, string serverOrigin)
            : this(sessionId, transactionId, association, serverOrigin, Guid.NewGuid())
        {
        }
        
        private InstrumentationContext(string sessionId, string transactionId, string association, string serverOrigin, Guid icid)
        {
            this.ICID = icid.ToString("N");
            this.TransactionId = string.IsNullOrEmpty(transactionId) ? this.ICID: transactionId;
            this.SessionId = sessionId;
            this.Association = association;
            this.ServerOrigin = serverOrigin;            
        }

        internal static InstrumentationContext Empty
        {
            get
            {
                return emptyContext;
            }
        }

        public string ICID { get; private set; }
        public string SessionId { get; private set; }               
        public string TransactionId { get; set; }       
        public string Association { get; set; }        
        public string ServerOrigin { get; set; }       
        public string ControllerName { get; set; }        
        public string ActionName { get; set; }        
        public string FullApiName { get; set; }
        public string InstanceNumber { get; set; }
        public string RoleName { get; set; }

        public static InstrumentationContext Current
        {
            get
            {
                var context = CallContext<InstrumentationContext>.GetData(InstrumentationLoggingContextKey);               
                return context;
            }

            protected set
            {
                if (value != null)
                {
                    CallContext<InstrumentationContext>.SetData(InstrumentationLoggingContextKey, value);
                }
                else
                {
                    CallContext<InstrumentationContext>.FreeNamedDataSlot(InstrumentationLoggingContextKey);
                }
               
            }
        }
       
        public InstrumentationContext AsCurrent()
        {
            Current = this;
            return this;
        }
    }
}
