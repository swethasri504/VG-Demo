﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using System.Net;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Http.Extensions;

    /// <summary>
    /// ASP.NET Core middleware which is used to measure the performance of REST APIs.
    /// </summary>
    public class TimedOperationMiddleware
    {
        internal const string InstrumentationLoggingContextKey = "InstrumentationLoggingContextKey";

        private const HttpStatusCode OperationCanceledStatusCode = (HttpStatusCode)418;

        /// <summary>
        /// The next ASP.NET Core middleware in line to be invoked.
        /// </summary>
        private RequestDelegate nextMiddleware;

        /// <summary>
        /// Initializes a new instance of the <see cref="TimedOperationMiddleware"/> class.
        /// </summary>
        public TimedOperationMiddleware(RequestDelegate nextMiddleware)
        {
            this.nextMiddleware = nextMiddleware;
        }

        /// <summary>
        /// Measure the performance of API.
        /// </summary>
        public async Task Invoke(HttpContext context)
        {
            var watch = new Stopwatch();
            var message = string.Empty;
            var code = HttpStatusCode.InternalServerError;
            var args = new InstrumentationArgs();

            try
            {
                watch.Start();
                await this.nextMiddleware(context);
            }
            catch (OperationCanceledException exception)
            {
                code = OperationCanceledStatusCode;
                args.Add("exception", exception);
                message = exception.Message;
            }
            catch (Exception exception)
            {
                args.Add("exception", exception);

                message = exception.Message;
                if (exception.InnerException != null)
                {
                    code = HttpStatusCode.InternalServerError;
                    message = message + Environment.NewLine + exception.InnerException;
                }
            }
            finally
            {
                watch.Stop();

                var duration = watch.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture);
                var request = context.Request;
                var response = context.Response;

                object iContext;
                context.Items.TryGetValue(InstrumentationLoggingContextKey, out iContext);
                var instrumentationContext = (iContext as InstrumentationContext).AsCurrent();

                if (instrumentationContext != null && !string.IsNullOrEmpty(instrumentationContext.FullApiName))
                {
                    args.Add("requestMethod", request.Method);
                    args.Add("requestUri", request.GetEncodedUrl());
                    args.Add("requestContentType", request.ContentType);
                    args.Add("requestContentLength", request.ContentLength);

                    code = (HttpStatusCode)response.StatusCode;
                    args.Add("statusCode", (int)code);

                    args.Add("durationInMilliseconds", duration);
                    args.Add("message", message);


                    var codeString = (code == OperationCanceledStatusCode) ? "Canceled" : code.ToString();

                    var format = string.Format("Response Time:{0} milliseconds", duration);

                    if (!string.IsNullOrWhiteSpace(message))
                    {
                        format += string.Format(" Message:\"{0}\"", message);
                    }

                    instrumentationContext.Log(
                        instrumentationContext.FullApiName + ".Status." + codeString,
                        ((int)code >= 200 && (int)code < 300) ? InstrumentationLevel.ApiSuccess : InstrumentationLevel.ApiFailure,
                        format,
                        args);
                }
            }
        }
    }
}
