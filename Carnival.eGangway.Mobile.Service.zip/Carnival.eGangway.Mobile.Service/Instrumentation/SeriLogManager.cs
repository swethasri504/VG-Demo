﻿using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.Collections.Generic;
using System.Text;

namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    public static class SeriLogManager
    {
        public static ILogger Logger { get; private set; }

        public static ILogger ConfigureSeriLog(IConfiguration configuration)
        {            
            if (Logger == null)
            {
                // assigning to Log.Logger is important.
                Logger = Log.Logger = new LoggerConfiguration()
                    .ReadFrom.Configuration(configuration)
                    .CreateLogger();
            }
            return Logger;           
        }
    }
}
