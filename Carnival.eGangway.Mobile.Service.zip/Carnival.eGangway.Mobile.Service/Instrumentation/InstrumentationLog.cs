﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    using System;
    using System.Collections.Generic;

    public class InstrumentationLog 
    {        
        public InstrumentationLog()
        {
            this.LogTime = DateTime.UtcNow;
        }
        
        public string LogId { get; set; }       
        public string RoleName { get; set; }       
        public string InstanceNumber { get; set; } 
        public DateTime LogTime { get; set; }
        public string Level { get; set; }      
        public string Name { get; set; }   
        public string TransactionId { get; set; }
        public string ICID { get; set; }
        public string SessionId { get; set; }
        public string Association { get; set; }
        public string ServerOrigin { get; set; }
        public string ListFields { get; set; }
    }
}
