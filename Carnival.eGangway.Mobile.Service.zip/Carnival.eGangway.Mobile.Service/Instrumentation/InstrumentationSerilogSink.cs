﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{ 
    using System;
    using System.Collections.Generic;
    
    /// <summary>
    /// An instrumentation sink that outputs to log output.
    /// </summary>
    public sealed class InstrumentationSerilogSink : IInstrumentationLogSink
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InstrumentationSerilogSink" /> class.
        /// </summary>
        public InstrumentationSerilogSink()
        {
        }

        private InstrumentationLog CreateLoggingEntity(
            string logId,
            InstrumentationContext context,
            InstrumentationLevel level,
            IReadOnlyCollection<KeyValuePair<string, object>> listFields)
        {

            var entity = new InstrumentationLog();

            //InstrumentationDataUtils.SetCommonFields(entity);

            entity.Level = level.ToString();
            entity.Name = logId ?? string.Empty;
            entity.TransactionId = context.TransactionId;
            entity.ICID = context.ICID;
            entity.InstanceNumber = context.InstanceNumber;
            entity.RoleName = context.RoleName;

            if (listFields != null)
            {
                entity.ListFields = InstrumentationDataUtils.SerializeListFieldsToJson(listFields);
            }

            if (context != null)
            {
                entity.SessionId = context.SessionId;
                entity.Association = context.Association;
                entity.ServerOrigin = context.ServerOrigin;
            }

            return entity;
        }
       
        private void Log(
            string logId,
            InstrumentationContext context,
            InstrumentationLevel level,
            IReadOnlyCollection<KeyValuePair<string, object>> listFields)
        {
            var logitem = this.CreateLoggingEntity(logId, context, @level, listFields);
            switch (level)
            {
                case InstrumentationLevel.Verbose:
                    SeriLogManager.Logger.Verbose("{@InstrumentationLog}", logitem);
                    break;
                case InstrumentationLevel.Debug:
                    SeriLogManager.Logger.Debug("{@InstrumentationLog}", logitem);
                    break;
                case InstrumentationLevel.Warning:
                    SeriLogManager.Logger.Warning("{@InstrumentationLog}", logitem);
                    break;
                case InstrumentationLevel.Error:
                case InstrumentationLevel.Exception:
                    SeriLogManager.Logger.Error("{@InstrumentationLog}", logitem);
                    break;
                case InstrumentationLevel.Fatal:
                    SeriLogManager.Logger.Fatal("{@InstrumentationLog}", logitem);
                    break;
                default:
                    SeriLogManager.Logger.Information("{@InstrumentationLog}", logitem);
                    break;
            }
        }
       
        public void LogMessage(
            string name,
            InstrumentationContext context,
            InstrumentationLevel level,
            IReadOnlyCollection<KeyValuePair<string, object>> dataFields = null)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentNullException("name");
            }

            this.Log(name, context, level, dataFields);
        }
      
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposalNative)
        {
        }

    }
}