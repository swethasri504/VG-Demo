﻿namespace Carnival.eGangway.Mobile.Service.Instrumentation
{
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;

    using Newtonsoft.Json;

    /// <summary>
    /// Internal Utilities for instrumentation module.
    /// </summary>
    public static class InstrumentationDataUtils
    {
        /// <summary>
        /// Serialize the ListFields to json.
        /// </summary>
        /// <param name="listFields">The listFields.</param>
        /// <returns>The Serialized ListFields.</returns>
        public static string SerializeListFieldsToJson(IReadOnlyCollection<KeyValuePair<string, object>> listFields)
        {
            // default empty array
            if (listFields == null || listFields.Count == 0)
            {
                return string.Empty;
            }

            using (var stringWriter = new StringWriter(CultureInfo.InvariantCulture))
            {
                var jsonWriter = new JsonTextWriter(new IndentedTextWriter(stringWriter));

                jsonWriter.WriteStartObject();

                foreach (var item in listFields)
                {
                    jsonWriter.WritePropertyName(item.Key);
                    if (item.Value == null)
                    {
                        jsonWriter.WriteNull();
                    }
                    else
                    {
                        if (item.Value is uint || item.Value is ushort || item.Value is ulong)
                        {
                            jsonWriter.WriteValue(item.Value);
                        }
                        else
                        {
                            jsonWriter.WriteValue(item.Value.ToString());
                        }
                    }
                }

                jsonWriter.WriteEndObject();

                // Flush out
                jsonWriter.Flush();

                return stringWriter.ToString();
            }
        }
    }
}
