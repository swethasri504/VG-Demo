﻿namespace Carnival.eGangway.Mobile.Service.Filter
{
    using System;
    using System.Linq;
    using Carnival.eGangway.Mobile.Service.Instrumentation;
    using Microsoft.AspNetCore.Http.Extensions;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.Mvc.Controllers;

    /// <summary>
    /// Extension methods for ActionContext
    /// </summary>
    public static class InstrumentationActionContextExtensions
    {
        
        /// <summary>
        /// Creates an instrumentation context from a ActionExecutingContext.
        /// </summary>
        public static InstrumentationContext AsInstrumentationContext(this ActionContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            string sessionId = null;
            string serverOrigin = null;
            string transactionId = null;
            string icid = null;
            string controllerName = null;
            string actionName = null;           
            string fullName = null;


            var request = context.HttpContext.Request;
            

            serverOrigin = request.GetEncodedUrl();
            transactionId = request.Headers[InstrumentationHttpHeaders.TransactionIdHeaderKey].FirstOrDefault();
            sessionId = request.Headers[InstrumentationHttpHeaders.SessionIdHeaderKey].FirstOrDefault();
            icid = request.Headers[InstrumentationHttpHeaders.IcIdHeaderKey].FirstOrDefault();


            var controllerActionDescriptor = context.ActionDescriptor as ControllerActionDescriptor;
            if (controllerActionDescriptor != null)
            {
                controllerName = controllerActionDescriptor.ControllerName;
                actionName = controllerActionDescriptor.ActionName;
                fullName = controllerActionDescriptor.DisplayName;

            }

            InstrumentationContext instrumentationContext = null;
            if (serverOrigin != null || sessionId != null || transactionId != null || icid != null || controllerName != null || actionName != null || fullName != null)
            {
                instrumentationContext = new InstrumentationContext(sessionId, transactionId, "-", serverOrigin)
                {
                    ControllerName = controllerName,
                    ActionName = actionName,
                    FullApiName = fullName,
                    Association = fullName,
                    InstanceNumber = HostConfiguration.ApplicationId,
                    RoleName = HostConfiguration.ServiceName

                };
            }

            return instrumentationContext;
        }
    }
}
