﻿namespace Carnival.eGangway.Mobile.Service.Filter
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using Microsoft.AspNetCore.Http.Extensions;
    using Microsoft.AspNetCore.Mvc.Filters;
        
    public sealed class InstrumentationActionContextAttribute : ActionFilterAttribute
    {
        internal const string InstrumentationLoggingContextKey = "InstrumentationLoggingContextKey";

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            try
            {
                var instrumentationContext = context.AsInstrumentationContext();
                if (instrumentationContext != null)
                {
                    instrumentationContext.AsCurrent();

                    // In case of exception, call context will be lost, so the instrumentation context should be stored in current httpcontext
                    context.HttpContext.Items[InstrumentationLoggingContextKey] = instrumentationContext;

                    context.HttpContext.Response.Headers.Add(InstrumentationHttpHeaders.IcIdHeaderKey, instrumentationContext.ICID);

                    context.HttpContext.Response.Headers.Add(InstrumentationHttpHeaders.TransactionIdHeaderKey, instrumentationContext.ICID);
                }
            }
            catch (Exception exception)
            {
                Trace.WriteLine(string.Format(CultureInfo.CurrentCulture, "[{0}] failed to set instrumentation context for request '{1}'\r\n{2}", DateTime.UtcNow, UriHelper.GetDisplayUrl(context.HttpContext.Request), exception));
            }
        }
    }
}
