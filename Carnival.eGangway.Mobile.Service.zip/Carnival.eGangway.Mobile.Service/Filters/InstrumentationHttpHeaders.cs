﻿namespace Carnival.eGangway.Mobile.Service.Filter
{

    public static class InstrumentationHttpHeaders
    {
        /// <summary>
        /// The instrumentation context identifier header name
        /// </summary>
        public const string TransactionIdHeaderKey = "x-vg-transactiondd";

        /// <summary>
        /// The instrumentation context identifier header name
        /// </summary>
        public const string IcIdHeaderKey = "x-vg-icid";

        /// <summary>
        /// The session id header key.
        /// </summary>
        public const string SessionIdHeaderKey = "x-vg-sessionId";
    }
}
