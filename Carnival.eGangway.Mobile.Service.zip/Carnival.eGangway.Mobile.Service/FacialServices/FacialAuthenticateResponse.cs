using Carnival.eGangway.Mobile.Service.Contracts;

namespace Carnival.eGangway.Mobile.Service
{
    public class FacialAuthenticateResponse : BaseResponse
    {
        public string Name { get; set; }
        public string FullName { get; set; }
        public long CreateTime { get; set; }
        public long LastModifyTime { get; set; }
        public object Password { get; set; }
        public object OldPassword { get; set; }
        public string Remark { get; set; }
        public string UserType { get; set; }    
        public string Token { get; set; }
    }
}
