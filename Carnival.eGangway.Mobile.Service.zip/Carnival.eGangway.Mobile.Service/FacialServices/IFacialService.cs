﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service
{
    public interface IFacialService
    {
        FacialAuthenticateResponse ProcessFacialServiceRequest();
        string GetFacialServiceToken();
    }
}
