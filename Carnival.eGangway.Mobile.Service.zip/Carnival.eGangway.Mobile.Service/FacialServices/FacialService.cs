﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Service
{
    public class FacialService: IFacialService
    {
        IConfiguration configuration;
        IConfigurationSection applicationSettings;
        ILogger logger;

        public FacialService(IConfiguration configuration, ILoggerFactory loggerfactory)
        {
            this.configuration = configuration;
            this.logger = loggerfactory.CreateLogger<LoginService>();
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
        }

        public FacialAuthenticateResponse ProcessFacialServiceRequest()
        {
            FacialAuthenticateResponse facialResponse = null;
            HttpResponseMessage response;

            var facialBaseUrl = this.applicationSettings.GetValue<string>("FacialServiceUri");
            var username = this.applicationSettings.GetValue<string>("FacialUsername");
            var password = this.applicationSettings.GetValue<string>("FacialPassword");
            var uniqueId = "0001";

            // set the values
            var url = $"{facialBaseUrl}/authenticationsrv/user/token?userName={username}&uniqueID={uniqueId}";

            var client = new HttpClient();

            using (var request = new HttpRequestMessage(HttpMethod.Get, url))
            {
                client.DefaultRequestHeaders.Add("password", password);
                response = client.SendAsync(request).Result;
                var result = response.Content != null ? response.Content.ReadAsStringAsync().Result : null;

                if (!response.IsSuccessStatusCode)
                {
                    return FacialAuthenticationFailedResponse();
                }

                // Deserialize the Response
                // need to serialize into business response, so get string first                
                if (string.IsNullOrEmpty(result))
                {
                    // if we did not get any reponse body, then we failed as seen from postman.
                    return FacialAuthenticationFailedResponse();
                }

                logger.LogDebug("External api response => StatusCode:{0} response: {1}", response.StatusCode, result);

                facialResponse = JsonConvert.DeserializeObject<FacialAuthenticateResponse>(result);

                // looks like the only way to figure out if we succeed. As Gemalto doesn't give any explicit indication
                // the best indication that I found so far is response has not-empty body and username is spitted back 
                // among other data
                facialResponse.Success = facialResponse.Name == username;

                if (!facialResponse.Success)
                {
                    return FacialAuthenticationFailedResponse();
                }
            }


            // came till here, then we succeeded
            var queryHeaders = from h in response.Headers select h;
            List<KeyValuePair<string, IEnumerable<string>>> headerList = queryHeaders.ToList();
            KeyValuePair<string, IEnumerable<string>> tokenHeader =
                headerList.Find(t => t.Key == "UserToken");

            IEnumerator<string> tokenEnumerator = tokenHeader.Value.GetEnumerator();
            string token = string.Empty;

            if (tokenEnumerator.MoveNext())
            {
                token = tokenEnumerator.Current;
            }

            // finally -- just in case we didn't get token for some reason, then that means we failed
            if (string.IsNullOrEmpty(token))
            {
                return FacialAuthenticationFailedResponse("No token retrieved");
            }

            // all done. Authentication success!
            facialResponse.Message = "Authentication Succeeded";
            facialResponse.Token = token;

            return facialResponse;
        }

        public string GetFacialServiceToken()
        {
            var res = ProcessFacialServiceRequest();
           return  res.Token;
        }


        private FacialAuthenticateResponse FacialAuthenticationFailedResponse(string message = null)
        {
            return new FacialAuthenticateResponse
            {
                Success = false,
                Message = "Authentication Failed " + message
            };
        }
    }
}
