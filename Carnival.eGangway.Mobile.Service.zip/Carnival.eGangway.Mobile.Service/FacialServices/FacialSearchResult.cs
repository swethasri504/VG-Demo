namespace Repositories.InternalMessages.Facial
{
    using System.Collections.Generic;
    public class FacialSearchResult
    {
            public int score { get; set; }
            public string personId { get; set; }
            public string personName { get; set; }
            public string sceneId { get; set; }
            public string category { get; set; }
            public string imageID { get; set; }
            public object image { get; set; }
    }

    public class FacialInternalSearchResponse
    {
        public List<FacialSearchResult> Results { get; set; }
    }
}
