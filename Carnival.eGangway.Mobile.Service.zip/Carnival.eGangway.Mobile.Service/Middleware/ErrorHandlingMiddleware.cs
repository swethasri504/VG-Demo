using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Instrumentation;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Carnival.eGangway.Mobile.Service
{
    public class ErrorHandlingMiddleware
    {
        internal const string InstrumentationLoggingContextKey = "InstrumentationLoggingContextKey";
        private readonly RequestDelegate next;
        private ILogger logger;        

        public ErrorHandlingMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            this.next = next;
            this.logger = loggerFactory.CreateLogger<ErrorHandlingMiddleware>();

        }

        public async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                object instrumentationContext;
                context.Items.TryGetValue(InstrumentationLoggingContextKey, out instrumentationContext);
                (instrumentationContext as InstrumentationContext).AsCurrent();
                InstrumentationContext.Current.Exception("Gangway.ErrorHandlingMiddleware", ex, ex.Source);                
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception ex)
        {            
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected
            var message = ReasonPharase.InternalServerServer;

            if(ex is InvalidOperationException || ex is ArgumentNullException || ex is ValidationException)
            {
                code = HttpStatusCode.BadRequest;
                message = ex.Message;
            }

            var result = JsonConvert.SerializeObject(new { error = message, responseCode=code });
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            return context.Response.WriteAsync(result);
        }
    }
}