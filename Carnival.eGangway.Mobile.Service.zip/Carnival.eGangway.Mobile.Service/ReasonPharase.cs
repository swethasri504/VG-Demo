﻿//------------------------------------------------------------------------------
// <copyright file="ReasonPharase.cs" company="Venusgeo.com">
//     Copyright Venusgeo.
// </copyright>
//------------------------------------------------------------------------------

namespace Carnival.eGangway.Mobile.Service
{
    public static class ReasonPharase
    {   
        public const string InternalServerServer = "The server encountered an internal error or misconfiguration and was unable to complete your request.";        

    }
}
