namespace Carnival.eGangway.Mobile.Service.Repository
{
    public interface ICacheService{
        void Add(Record record);
        Record Get(string MD5);
        void Remove(string Id);
    }
}