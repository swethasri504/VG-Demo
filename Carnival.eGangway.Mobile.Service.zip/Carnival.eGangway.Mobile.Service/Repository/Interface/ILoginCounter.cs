namespace Carnival.eGangway.Mobile.Service.Repository
{
    public interface ILoginCounter{
        void Add(string userName);
        LoginCounter Get(string userName);
        void Remove(string userName);
    }
}