using System.Collections.Generic;

namespace Carnival.eGangway.Mobile.Service.Repository
{
    public class CacheService : ICacheService
    {
        private List<Record> table;

        public CacheService()
        {
            table = new List<Record>();
        }

        public void Add(Record record)
        {
            table.Add(record);
        }

        public Record Get(string MD5)
        {
            return table.Find(x => x.MD5 == MD5);
        }

        public void Remove(string MD5)
        {
            var record = Get(MD5);
            if (record != null)
                table.Remove(record);
        }

    }

}