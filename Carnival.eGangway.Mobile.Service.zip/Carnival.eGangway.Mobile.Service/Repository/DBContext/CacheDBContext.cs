using Microsoft.EntityFrameworkCore;

namespace Carnival.eGangway.Mobile.Service.Repository
{
    public class CacheDBContext : DbContext
    {
        private readonly string dataBasePath;
      
        public CacheDBContext(string path)
        {
            this.dataBasePath = path;
        }
        public DbSet<Record> Records { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source="+this.dataBasePath);
        }

    }
}