using System.Collections.Generic;

namespace Carnival.eGangway.Mobile.Service.Repository
{
    public class LoginCounterService :ILoginCounter
    {
        private List<LoginCounter> table;

        public LoginCounterService()
        {
            table = new List<LoginCounter>();
        }

        public void Add(string userName)
        {
             var user=Get(userName);
            if (user==null)
                table.Add(new LoginCounter{UserName=userName,Attempt=1});
            else
                Upate(user);    
        }

        public LoginCounter Get(string userName)
        {
            return table.Find(x=>x.UserName==userName);
        }

        public void Remove(string userName)
        {
            var user =Get(userName);
            if (user !=null)
                table.Remove(user);
        }

        private void Upate(LoginCounter user)
        {
           var obj = table.Find(x => x.UserName == user.UserName);
            if (obj != null) 
                obj.Attempt=obj.Attempt+1;
        }
    }
     
}