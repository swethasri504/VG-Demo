using System;
using Carnival.eGangway.Mobile.Service.Contracts;

namespace Carnival.eGangway.Mobile.Service
{
    public class Record{
        
        public string Id  {get;set;}
        
        public string MD5  {get;set;}

        public DateTime StartDate  {get;set;}

        public string Response{get;set;}

    }
}