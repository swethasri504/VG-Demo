namespace Carnival.eGangway.Mobile.Service
{
    public class LoginCounter{
        public string UserName  {get;set;}
        
        public int Attempt  {get;set;}

    }
}