using System.Linq;
using Microsoft.Extensions.Configuration;

namespace Carnival.eGangway.Mobile.Service.Repository
{
    public class CacheDBService:ICacheService
    {
        IConfiguration configuration;
        IConfigurationSection applicationSettings;

        CacheDBContext dBContext;  
        public CacheDBService(IConfiguration configuration)
        {
            this.configuration = configuration;
            this.applicationSettings = configuration.GetSection("ApplicationSettings");
            var path = this.applicationSettings.GetValue<string>("CacheDataBasePath");
            this.dBContext = new CacheDBContext(path);
        }

        public void Add(Record record)
        {
            this.dBContext.Records.Add(record);
            this.dBContext.SaveChanges();
        }

        public Record Get(string MD5)
        {
            return this.dBContext.Records.FirstOrDefault(x => x.MD5 == MD5);
        }

        public void Remove(string Id)
        {
            var recordList = this.dBContext.Records.Where(x => x.Id == Id).ToList();
            foreach (var record in recordList)
            {
                this.dBContext.Records.Remove(record);
            }
            this.dBContext.SaveChanges();
        }


    }
}