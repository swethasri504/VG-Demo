﻿using System.Net;
using Carnival.eGangway.Mobile.Service.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Carnival.eGangway.Mobile.Service.Helpers;
using System.ComponentModel.DataAnnotations;

namespace Carnival.eGangway.Mobile.Service.Controllers
{
    public class UpdateEventController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IUpdateEventService EventService;

        public UpdateEventController(IConfiguration config, IUpdateEventService service)
        {
            this.configuration = config;
            this.EventService = service;
        }

        // Update Movement
        [HttpPost]
        [Route(Routes.UpdateEvent)]
        public IActionResult UpdateEvent([FromBody] UpdateEventRequest request)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }
            var response = this.EventService.UpdateEvent(request);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}