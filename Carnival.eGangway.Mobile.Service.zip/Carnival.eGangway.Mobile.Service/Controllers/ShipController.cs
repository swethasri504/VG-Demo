﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Carnival.eGangway.Mobile.Service.Controllers
{  
    [ApiController]
    public class ShipController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IShipService shipService;

        public ShipController(IConfiguration config, IShipService service)
        {
            this.configuration = config;
            this.shipService = service;
        }

        // GET ships
        [HttpGet]
        [Route(Routes.Ships)]
        public IActionResult Get()
        {   
            var response = this.shipService.GetShips();
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        // GET ships
        [HttpGet]
        [Route(Routes.Ship)]
        public IActionResult GetSpecificship()
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            var response = this.shipService.GetShipByCode();
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}