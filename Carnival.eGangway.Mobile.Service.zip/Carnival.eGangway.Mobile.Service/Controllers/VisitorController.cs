﻿using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Controllers
{
    public class VisitorController :ControllerBase
    {
        private readonly IConfiguration configuration;
        private IVisitorService VisitorService;

        public VisitorController(IConfiguration config, IVisitorService visitorService)
        {
            this.configuration = config;
            this.VisitorService = visitorService;
        }

        // Add visitor
        [HttpPost]
        [Route(Routes.AddVisitor)]
        public IActionResult AddVisitor([FromBody] VisitorRequest request)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }
            var response = this.VisitorService.Create(request);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
