﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Contracts;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Carnival.eGangway.Mobile.Service.Controllers
{
    public class UpdatephotoController : ControllerBase
    {
		private readonly IConfiguration configuration;
		private IUpdatePhotoService UpdatePhotoService;

		public UpdatephotoController(IConfiguration config, IUpdatePhotoService updatephotoservice)
		{
			this.configuration = config;
			this.UpdatePhotoService = updatephotoservice;
		}

		// update Photo
		[HttpPost]
		[Route(Routes.UpdatePhoto)]
		public IActionResult AddVisitor([FromBody] UpdatePhotoRequest request)
		{
			if (!ModelState.IsValid)
			{
				throw new ValidationException();
			}
			var response = this.UpdatePhotoService.UpdatePhoto(request);
			return this.Request.CreateResponse(HttpStatusCode.OK, response);
		}

        [HttpPost]
        [Route(Routes.UpdatePhotoCache)]
        public IActionResult UpdatePhotoCache(string transactionId)
        {
            this.UpdatePhotoService.UpdatePhotoCache(transactionId);
            return this.Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}