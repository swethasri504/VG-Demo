﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Helpers;
using Carnival.eGangway.Mobile.Service.Instrumentation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Carnival.eGangway.Mobile.Service.Controllers
{  
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IDashboardService dashboardService;

        public DashboardController(IConfiguration config, IDashboardService service)
        {
            this.configuration = config;
            this.dashboardService = service;
        }

        // GET dashboard/voyno
        [HttpGet]
        [Route(Routes.Dashboard)]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        public IActionResult Get([FromQuery]string voyno)
        {
            InstrumentationContext.Current.Information(
               "Gangway.Middleware.Dashboard.Service", "Get Call", new InstrumentationArgs { { "voyno", voyno } } );

            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            var response = this.dashboardService.GetCounts(voyno.Split(',').ToList());
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
       
    }
}