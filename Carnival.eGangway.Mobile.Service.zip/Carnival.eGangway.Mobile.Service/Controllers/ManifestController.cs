﻿//------------------------------------------------------------------------------
// <copyright file="TokenController.cs" company="Venusgeo.com">
//     Copyright Venusgeo.
// </copyright>
//------------------------------------------------------------------------------

namespace Carnival.eGangway.Mobile.Service.Controllers
{   
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Net;
    using Carnival.eGangway.Mobile.Service.Contracts;
    using Carnival.eGangway.Mobile.Service.Helpers;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;

    [ApiController]
    public class ManifestController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IManifestService menifestService;

        public ManifestController(IConfiguration config, IManifestService service)
        {
            this.configuration = config;
            this.menifestService = service;
        }

        // GET manifest
        [HttpGet]
        [Route(Routes.Manifest)]
        public IActionResult Manifest([FromQuery]string shipid, [FromQuery]string deviceid)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            var request = new ManifestRequest { ShipId = shipid, DeviceId = deviceid, AccessToken = this.Request.Headers["x-accesstoken"] };

            var response = this.menifestService.GetResponse(request);

            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

    }
}
