﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Carnival.eGangway.Mobile.Service.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Carnival.eGangway.Mobile.Service.Controllers
{  
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IPersonService personService;

        public PersonController(IConfiguration config, IPersonService service)
        {
            this.configuration = config;
            this.personService = service;
        }

        // GET person/voyno
        [HttpGet]
        [Route(Routes.Person)]
        public IActionResult Get(string voyno)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            var response = this.personService.GetPerson(voyno);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }
       
    }
}