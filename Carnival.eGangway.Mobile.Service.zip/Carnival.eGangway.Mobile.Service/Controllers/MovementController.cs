﻿using System.Net;
using Carnival.eGangway.Mobile.Service.Contracts;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Carnival.eGangway.Mobile.Service.Helpers;
using System.ComponentModel.DataAnnotations;

namespace Carnival.eGangway.Mobile.Service.Controllers
{
    public class MovementController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private IMovementService MovementService;
        private IUpdateEventService UpdateEventService;

        public MovementController(IConfiguration config, IMovementService movementService, IUpdateEventService eventService)
        {
            this.configuration = config;
            this.MovementService = movementService;
            this.UpdateEventService = eventService;
        }

        // Update Movement
        [HttpPost]
        [Route(Routes.UpdateMovementAndEvent)]
        public IActionResult UpdateMovement([FromBody] UpdateMovementAndEventRequest request)
        {
            UpdateEventResponse eventError = null;
            if (!ModelState.IsValid)
                throw new ValidationException();
          
            foreach (var eve in request.EventDetails)
            {               
                var response = this.UpdateEventService.UpdateEvent(eve);
                if (response.Status == "N") {
                    eventError = response;
                    break;
                }
            }   
            if (eventError != null)
                return this.Request.CreateResponse(HttpStatusCode.OK,eventError);

            var updateMovementResponse = this.MovementService.UpdateMovement(request.UpdateMovement);
            return this.Request.CreateResponse(HttpStatusCode.OK, updateMovementResponse);
        }

        // Update Movement
        [HttpPost]
        [Route(Routes.UpdateMovement)]
        public IActionResult UpdateMovement([FromBody] UpdateMovementRequest request)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }
            var response = this.MovementService.UpdateMovement(request);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        [Route(Routes.UpdateCache)]
        public IActionResult UpdateCache(string transactionId){
            this.MovementService.UpdateCache(transactionId);
            return this.Request.CreateResponse(HttpStatusCode.OK);
        }
    }

}