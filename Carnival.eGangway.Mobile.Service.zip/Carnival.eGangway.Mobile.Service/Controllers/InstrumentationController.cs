﻿////using System;
////using System.Collections.Generic;
////using System.Linq;
////using System.Threading.Tasks;
////using Carnival.eGangway.Mobile.Service.Instrumentation;
////using Microsoft.AspNetCore.Http;
////using Microsoft.AspNetCore.Mvc;

////namespace Carnival.eGangway.Mobile.Service.Controllers
////{
    
////    [ApiController]
////    public class InstrumentationController : ControllerBase
////    {
////        // Update Movement
////        [HttpPost]
////        [Route(Routes.Instrumentation)]
////        public IActionResult UpdateMovement([FromBody] InstrumentationArgs instrumentationArgs)
////        {
////            UpdateEventResponse eventError = null;
////            if (!ModelState.IsValid)
////                throw new ValidationException();

////            foreach (var eve in request.EventDetails)
////            {
////                var response = this.UpdateEventService.UpdateEvent(eve);
////                if (response.Status == "N")
////                {
////                    eventError = response;
////                    break;
////                }
////            }
////            if (eventError != null)
////                return this.Request.CreateResponse(HttpStatusCode.OK, eventError);

////            var updateMovementResponse = this.MovementService.UpdateMovement(request.UpdateMovement);
////            return this.Request.CreateResponse(HttpStatusCode.OK, updateMovementResponse);
////        }
////    }
////}