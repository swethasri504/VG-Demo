﻿//------------------------------------------------------------------------------
// <copyright file="TokenController.cs" company="Venusgeo.com">
//     Copyright Venusgeo.
// </copyright>
//------------------------------------------------------------------------------


using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Carnival.eGangway.Mobile.Service.Controllers
{
    using Contracts;
    using Helpers;
    using System.ComponentModel.DataAnnotations;

    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private ILoginService loginService;
        private ICrewLoginService crewLoginService;

        public AuthController(IConfiguration config, ILoginService service, ICrewLoginService crewLoginService)
        {
            this.configuration = config;
            this.loginService = service;
            this.crewLoginService = crewLoginService;
        }
       
        // GET auth/login
        [HttpPost]
        [Route(Routes.Login)]
        public IActionResult Login([FromBody]LoginRequest request)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            /*
             * TODO: Crew login 
            if (request.AgentType.ToLower() == "crew")
            {
                var requestData = new CrewLoginRequestData { LoginId = request.UserName, Password = request.Password };
                var crewRequest = new CrewLoginRequest();
                crewRequest.Data.Add(requestData);
                var crewLoginresponse = this.crewLoginService.GetCrewUser(crewRequest);
                return this.Request.CreateResponse(HttpStatusCode.OK, crewLoginresponse);
            }
           */

            var response = this.loginService.GetUser(request);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
           
        }

        // GET auth/login/admin
        [HttpPost]
        [Route(Routes.AdminLogin)]
        public IActionResult AdminLogin([FromBody]LoginRequest request)
        {
            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }
            var response = this.loginService.GetAdminUser(request);
            return this.Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPut]
        [Route(Routes.AdminReset)]
        public IActionResult ResetPassword([FromBody]LoginRequest request, [FromQuery] string resetUser)
        {
            if (String.IsNullOrEmpty(resetUser))
            {
                throw new ValidationException("User name provided is null or empty");
            }

            if (!ModelState.IsValid)
            {
                throw new ValidationException();
            }

            this.loginService.ResetPassword(request, resetUser);
            return this.Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
