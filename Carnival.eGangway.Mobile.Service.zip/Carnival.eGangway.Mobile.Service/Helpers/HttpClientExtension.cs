﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="HttpRequestMessageExtension.cs" company="Venusgeo.com">
//   Copyright Venusgeo.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Carnival.eGangway.Mobile.Service.Helpers
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;

    public static class HttpClientExtension
    {   
       public const string LATITUDEAUTHTOKEN = "LATITUDE_AUTH_TOKEN";

        public static HttpClient AddLatitudeAuthTokenHeader(this HttpClient client, string authToken)
        {
            client.DefaultRequestHeaders.Add(LATITUDEAUTHTOKEN, authToken);
            return client;
        }       
    }
}
