﻿using Carnival.eGangway.Mobile.Service.Instrumentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Helpers
{
    public static class InstrmentationLogHelper
    {
        public static void LogExternalApiResponse(string name, string requestUri, string httpMethod, HttpStatusCode statusCode, string result = null, string duration = null, string deviceid = null)
        {
            var args = new InstrumentationArgs();

            args.Add("requestMethod", httpMethod);
            args.Add("requestUri", requestUri);
            args.Add("statusCode", (int)statusCode);            
            if (!string.IsNullOrEmpty(deviceid)) args.Add("deviceid", deviceid);
            if (!string.IsNullOrEmpty(duration)) args.Add("durationInMilliseconds", duration);
            if (!string.IsNullOrEmpty(result)) args.Add("message", result);

            var format = string.Format("{0}.Response Time:{1} milliseconds", name, duration );           
            if (!string.IsNullOrWhiteSpace(result))
            {
                format += string.Format(" Message:\"{0}\"", result);
            }

            InstrumentationContext.Current.Log(
                name + ".Status." + statusCode.ToString(),
                ((int)statusCode >= 200 && (int)statusCode < 300) ? InstrumentationLevel.ApiSuccess : InstrumentationLevel.ApiFailure,
                format,
                args);
        }
    }
}
