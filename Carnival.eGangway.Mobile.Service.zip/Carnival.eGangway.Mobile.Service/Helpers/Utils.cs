﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Carnival.eGangway.Mobile.Service.Helpers
{
    public static class Utils
    {
        public static void InvalidOperationExceptionResponse(string parameterName)
        {
            var message = string.Format("Invalid value for request parameter [{0}]", parameterName);
            throw new InvalidOperationException(message);
        }
    }
}
